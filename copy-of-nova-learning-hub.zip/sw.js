const CACHE_NAME = 'nova-learning-hub-v1';
const URLS_TO_CACHE = [
  '/',
  './index.html',
  './index.tsx',
  './App.tsx',
  './types.ts',
  './constants.ts',
  './components/FooterNav.tsx',
  './components/Icons.tsx',
  './components/CodeEditor.tsx',
  './components/Toast.tsx',
  './contexts/UserContext.tsx',
  './contexts/ThemeContext.tsx',
  './contexts/BookmarkContext.tsx',
  './contexts/NotificationContext.tsx',
  './contexts/ToastContext.tsx',
  './services/geminiService.ts',
  './pages/Dashboard.tsx',
  './pages/Courses.tsx',
  './pages/CourseDetail.tsx',
  './pages/ChapterView.tsx',
  './pages/Challenges.tsx',
  './pages/Search.tsx',
  './pages/Profile.tsx',
  './pages/NotFound.tsx',
  './pages/Onboarding.tsx',
  './pages/EditProfile.tsx',
  './pages/Settings.tsx',
  './pages/Bookmarks.tsx',
  './pages/Community.tsx',
  'https://cdn.tailwindcss.com'
];

// Install event: cache all the core assets.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache. Caching app shell.');
        return cache.addAll(URLS_TO_CACHE);
      })
  );
});

// Activate event: clean up old caches.
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Fetch event: serve from cache first, fall back to network.
self.addEventListener('fetch', event => {
  // We only want to cache GET requests.
  if (event.request.method !== 'GET') {
    return;
  }
  
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }
        // Not in cache, so fetch from network.
        return fetch(event.request);
      }
    )
  );
});