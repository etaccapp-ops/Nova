import { Course, Badge, User, QuizQuestion, LabChallenge } from './types';

export const DEFAULT_USER: User = {
    name: "Alex Ray",
    avatar: "https://i.pravatar.cc/150?u=a042581f4e29026704d",
    title: "Student",
    status: "Beginner Coder",
    points: 85,
    dailyStreak: 3,
    longestStreak: 21,
    challengesCompleted: 12,
    achievements: 4,
    certificateProgress: 10,
    hoursLearned: 54,
    completedCourses: 2,
    goal: "Career Change",
    email: "user@example.com",
};

export const RECENT_ACHIEVEMENTS: Badge[] = [
    { name: "HTML Explorer", description: "Completed Module 1", image: "https://picsum.photos/seed/badge1/100" },
    { name: "CSS Apprentice", description: "Styled your first page", image: "https://picsum.photos/seed/badge2/100" },
];

const htmlBoilerplate = (title: string, bodyContent: string = '<!-- Your code goes here -->') => `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
</head>
<body>
  ${bodyContent}
</body>
</html>`;

const advancedEditorConfig = {
    autoTagRecommendation: true,
    autoCloseTags: true,
    syntaxErrorDetection: true,
};

export const LAB_CHALLENGES: LabChallenge[] = [
    {
        id: "stock-widget",
        level: "intermediate",
        title: "Stock Market Widget",
        description: "Create a stock market widget showing real-time stock data with price chart and statistics.",
        requirements: [
          "Company header with name and ticker symbol",
          "Current price with change indicator (up/down)",
          "Price change in points and percentage",
          "Time period selector (1DAY, 1WEEK, 1MONTH)",
          "Price chart area with timeline",
          "Latest price update timestamp",
          "Responsive layout that works on mobile and desktop",
        ],
        hint: "Use semantic HTML for financial data. Consider using <table> for price data and <svg> or a placeholder div for the chart area.",
        referenceItems: [
          {
            type: 'image',
            url: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1200",
            description: "Stock widget showing price, chart, and market data."
          }
        ],
        constraints: [
          "Must use semantic HTML for financial information",
          "Chart can be simplified with placeholder elements",
          "Focus on data structure and accessibility",
          "No external charting libraries - use pure HTML/CSS"
        ],
        initialCode: {
          html: htmlBoilerplate("Stock Widget", `<div class="stock-widget">
    <!-- Your HTML here -->
</div>`),
          css: `/* Style the stock widget to match the reference design */
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
  background-color: #f0f2f5;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
}
.stock-widget {
    background-color: white;
    border-radius: 16px;
    padding: 24px;
    width: 380px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}
`
        },
        uiConfig: {
          previewMode: "in-app-preview",
          defaultDevice: "desktop",
        },
        editorConfig: advancedEditorConfig
      },
  {
    id: "mf-website-1",
    level: "easy",
    title: "Motherfucking Website",
    description: "Recreate the original 'Motherfucking Website' using pure HTML only—no CSS allowed! Focus on semantic structure and let the browser do the styling.",
    requirements: [
      "Use proper HTML5 semantic structure.",
      "Recreate the exact content hierarchy.",
      "Include all headings, paragraphs, and lists.",
      "No CSS styling allowed.",
    ],
    initialCode: {
      html: `<!DOCTYPE html>
<html>
<head>
  <title>This is a motherfucking website.</title>
</head>
<body>
  <!-- Your code goes here -->
</body>
</html>`,
    },
    referenceItems: [
      {
        type: 'component',
        componentId: 'MotherfuckingWebsitePreview',
        description: "A preview of the original Motherfucking Website. Focus on the raw HTML structure."
      }
    ],
    editorConfig: advancedEditorConfig,
  },
  {
    id: "mf-website-2",
    level: "intermediate",
    title: "Better Motherfucking Website",
    description: "Recreate the 'Better Motherfucking Website' with minimal CSS (7 declarations max) to improve readability.",
    requirements: [
      "Recreate the improved version's content.",
      "Use a maximum of 7 CSS declarations.",
      "Implement proper line-height and max-width.",
      "Adjust text size and reduce contrast.",
    ],
    initialCode: {
      html: `<!DOCTYPE html>
<html>
<head>
  <title>This is still a motherfucking website.</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <!-- Your code here -->
</body>
</html>`,
      css: `/* You get exactly 7 declarations - use them wisely! */
body {
  
}`
    },
    referenceItems: [
      {
        type: 'component',
        componentId: 'BetterMotherfuckingWebsitePreview',
        description: "A preview of the Better Motherfucking Website. Focus on simple CSS for readability."
      }
    ],
    editorConfig: advancedEditorConfig
  },
    {
    id: "recreate-design-1",
    level: "easy",
    title: "Simple Component Recreation",
    description: "This simple layout with a header, paragraph, and button was built using HTML. Recreate it in the editor below.",
    initialCode: {
        html: htmlBoilerplate("My Page")
    },
    referenceItems: [
        {
          type: 'image',
          url: "https://picsum.photos/seed/design/600/400",
          description: "A simple card layout with a title, text, and a button."
        }
    ],
    editorConfig: advancedEditorConfig
  },
  // NEW CHALLENGES START HERE
  {
      id: "beginner-1",
      level: "easy",
      title: "Personal Bio Page",
      description: "Create a simple personal biography page using semantic HTML tags.",
      requirements: [
        "Use proper HTML5 doctype and structure",
        "Include a header with your name as h1",
        "Add a short bio in a paragraph",
        "Create a list of your hobbies",
        "Add a contact email link"
      ],
      hint: "Use <header>, <main>, <ul> or <ol>, and <a href='mailto:'>",
      initialCode: { html: htmlBoilerplate("Personal Bio Page") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "beginner-2",
      level: "easy",
      title: "Recipe Card",
      description: "Build a structured recipe page using appropriate HTML elements.",
      requirements: [
        "Recipe title as h1",
        "Description paragraph",
        "Unordered list for ingredients",
        "Ordered list for instructions",
        "Preparation time using <time> tag"
      ],
      hint: "Use <ul> for ingredients, <ol> for steps, and <time datetime='PT30M'>",
      initialCode: { html: htmlBoilerplate("Recipe Card") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "beginner-3",
      level: "easy",
      title: "Simple Contact Form",
      description: "Create a functional contact form with various input types.",
      requirements: [
        "Name text input",
        "Email input with validation",
        "Dropdown for subject",
        "Message textarea",
        "Submit button"
      ],
      hint: "Use <form>, <input type='email'>, <select>, and <textarea>",
      initialCode: { html: htmlBoilerplate("Simple Contact Form") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "beginner-4",
      level: "easy",
      title: "Book Chapter Layout",
      description: "Structure a book chapter with proper heading hierarchy.",
      requirements: [
        "Chapter title as h1",
        "Chapter introduction",
        "At least 3 sections with h2 headings",
        "Use blockquote for a quotation",
        "Add a footnote section"
      ],
      hint: "Use <h1> through <h6> hierarchy and <blockquote>",
      initialCode: { html: htmlBoilerplate("Book Chapter Layout") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "beginner-5",
      level: "easy",
      title: "Event Schedule Table",
      description: "Create an accessible event schedule using table elements.",
      requirements: [
        "Table with headers for Time, Event, and Location",
        "At least 5 event rows",
        "Use thead and tbody",
        "Add a table caption",
        "Make it accessible with scope attributes"
      ],
      hint: "Use <table>, <thead>, <tbody>, <th scope='col'>",
      initialCode: { html: htmlBoilerplate("Event Schedule Table") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "intermediate-1",
      level: "intermediate",
      title: "Technical Documentation",
      description: "Build a technical documentation page with navigation.",
      requirements: [
        "Sidebar navigation linking to sections",
        "Multiple content sections",
        "Code examples using <code> and <pre>",
        "API endpoint documentation",
        "Footer with copyright"
      ],
      hint: "Use <nav> for sidebar, <section> for content, <code> for inline code",
      initialCode: { html: htmlBoilerplate("Technical Documentation") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "intermediate-2",
      level: "intermediate",
      title: "Blog Post with Comments",
      description: "Create a blog post layout with comment threading.",
      requirements: [
        "Blog post with title, meta info, and content",
        "Comments section with multiple comments",
        "Nested replies to comments",
        "Author information for each comment",
        "Timestamp for posts and comments"
      ],
      hint: "Use <article> for main post, nested <article> or <div> for comments",
      initialCode: { html: htmlBoilerplate("Blog Post with Comments") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "intermediate-3",
      level: "intermediate",
      title: "Product Comparison Table",
      description: "Build an accessible product comparison table.",
      requirements: [
        "Compare at least 3 products",
        "Features as row headers",
        "Pricing information",
        "Rating system using text",
        "Call-to-action links for each product"
      ],
      hint: "Use <th scope='row'> for features, structured data with proper headers",
      initialCode: { html: htmlBoilerplate("Product Comparison Table") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "intermediate-4",
      level: "intermediate",
      title: "FAQ Accordion (HTML Only)",
      description: "Create an FAQ section using only HTML semantics.",
      requirements: [
        "Use details and summary tags",
        "At least 5 FAQ items",
        "Proper heading structure",
        "Categorize FAQs if possible",
        "Search-engine friendly content"
      ],
      hint: "Use <details> and <summary> for collapsible sections",
      initialCode: { html: htmlBoilerplate("FAQ Accordion") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "intermediate-5",
      level: "intermediate",
      title: "Academic Paper Structure",
      description: "Structure a formal academic paper using semantic HTML.",
      requirements: [
        "Abstract section",
        "Introduction with citations",
        "Methodology description",
        "Results with data tables",
        "References list with proper formatting"
      ],
      hint: "Use <section>, <cite>, <table>, and ordered lists for references",
      initialCode: { html: htmlBoilerplate("Academic Paper Structure") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "intermediate-6",
      level: "intermediate",
      title: "Job Application Form",
      description: "Create a comprehensive job application form.",
      requirements: [
        "Personal information section",
        "Work experience with multiple entries",
        "Education history",
        "File upload for resume",
        "Terms and conditions agreement"
      ],
      hint: "Use <fieldset> and <legend> to group form sections",
      initialCode: { html: htmlBoilerplate("Job Application Form") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "advanced-1",
      level: "hard",
      title: "Multi-page Website Navigation",
      description: "Create a cohesive multi-page website structure.",
      requirements: [
        "Homepage with site overview",
        "About page with team information",
        "Services/Products page",
        "Contact page with form",
        "Consistent navigation across all pages"
      ],
      hint: "Create multiple HTML files with consistent <nav> structure",
      initialCode: { html: htmlBoilerplate("Homepage") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "advanced-2",
      level: "hard",
      title: "Accessible Data Dashboard",
      description: "Build a complex dashboard layout using semantic HTML.",
      requirements: [
        "Header with user info and notifications",
        "Sidebar navigation with multiple sections",
        "Main content area with widgets",
        "Data tables with sorting indicators",
        "Footer with multiple link sections"
      ],
      hint: "Use <header>, <nav>, <main>, <aside>, <section> for layout",
      initialCode: { html: htmlBoilerplate("Data Dashboard") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "advanced-3",
      level: "hard",
      title: "E-commerce Product Listing",
      description: "Build a product catalog page with filtering options.",
      requirements: [
        "Product grid using semantic markup",
        "Filter sidebar with categories",
        "Search functionality form",
        "Product details with variants",
        "Shopping cart summary"
      ],
      hint: "Use <section> for filters, <article> for products, <form> for search",
      initialCode: { html: htmlBoilerplate("E-commerce Products") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "advanced-4",
      level: "hard",
      title: "Interactive Quiz Application",
      description: "Create a complete quiz with multiple question types.",
      requirements: [
        "Multiple choice questions",
        "True/False questions",
        "Multiple answer questions",
        "Progress indicator",
        "Results summary page"
      ],
      hint: "Use <form> with <fieldset>, different input types, and hidden sections",
      initialCode: { html: htmlBoilerplate("Quiz Application") },
      editorConfig: advancedEditorConfig
    },
    {
      id: "advanced-5",
      level: "hard",
      title: "News Portal Homepage",
      description: "Build a complex news website homepage.",
      requirements: [
        "Breaking news banner",
        "Featured article section",
        "Category-based article lists",
        "Newsletter signup form",
        "Social media links and footer"
      ],
      hint: "Use <article> for news items, <time> for dates, <aside> for related content",
      initialCode: { html: htmlBoilerplate("News Portal") },
      editorConfig: advancedEditorConfig
    }
];


const htmlLesson1Quiz: QuizQuestion[] = [
    { question: "What does HTML stand for?", options: ["Hyperlink Markup Language", "HyperText Markup Language", "Hyper Transfer Machine Language"], answer: "HyperText Markup Language" },
    { question: "Which tag defines the main visible content?", options: ["<head>", "<body>", "<html>"], answer: "<body>"},
    { question: "What’s the correct order of sections in HTML?", options: ["<html>, <head>, <body>, <!DOCTYPE>", "<!DOCTYPE>, <html>, <head>, <body>", "<body>, <head>, <html>, <!DOCTYPE>"], answer: "<!DOCTYPE>, <html>, <head>, <body>"},
    { question: "What happens if you forget a closing </p> tag?", options: ["The page will crash", "The text will disappear", "The browser often auto-closes it, but it may cause layout bugs"], answer: "The browser often auto-closes it, but it may cause layout bugs"}
];

export const COURSES_DATA: Course[] = [
    {
        id: "html-fundamentals",
        title: "HTML Fundamentals",
        description: "Learn the basics of HTML structure, elements, and best practices to build your first web pages from scratch.",
        imageUrl: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        level: "Beginner",
        modules: [
            {
                id: "module-1-core-concepts",
                title: "Introduction & Core Concepts",
                chapters: [
                    {
                        id: "lesson-1-what-is-html",
                        title: "The Apprentice’s Foundation",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📘 The Apprentice’s Foundation: How the Digital World Works</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~10–15 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">🧭 I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">“Ever stared at a webpage and wondered — how does that text, image, or button actually appear? It’s like magic… but it’s really just structured code called HTML — the invisible skeleton of the web.”</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💡 What You Should Know Before Starting</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Absolutely nothing — this is your very first step. All you need is curiosity and a browser (like Chrome or Firefox).</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">⚙️ Setup & Configuration</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Before we start, let’s prepare your mini web lab:</p>
                            <ol class="list-decimal list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Create a Folder:</strong> <code>MyFirstWebsite</code></li>
                                <li>Inside it, create a file called <code>index.html</code></li>
                                <li>Open it using a code editor — Visual Studio Code (recommended).</li>
                                <li>Right-click → <strong>Open with Browser</strong> to preview your work.</li>
                            </ol>
                            <div class="bg-blue-50 dark:bg-slate-800/60 border-l-4 border-blue-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-blue-800 dark:text-blue-200">💬 <strong>Tip:</strong> You can even use Notepad or TextEdit if you want — the browser does all the magic!</p>
                            </div>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">By the end of this lesson, you’ll:</p>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Understand what HTML really is and why it exists.</li>
                                <li>Learn how browsers interpret HTML files.</li>
                                <li>Create your very first webpage and see it live!</li>
                                <li>Be ready to move toward more advanced structures and tags.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💼 Why This Matters</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Every digital experience — from Facebook to Google — begins with HTML. Learning it is like learning to read the DNA of the internet. With HTML, you’ll not only <strong>use</strong> the web — you’ll <strong>create</strong> it.</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">🧠 II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Simple Analogy</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">“Think of HTML as the <strong>skeleton</strong> of a human body. It gives shape, but not color or style — CSS and JavaScript are the muscles and brain that bring it to life.”</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💻 Annotated Code Example</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!DOCTYPE html&gt; &lt;!-- Declares HTML5 document --&gt;
&lt;html&gt;
&lt;head&gt;
  &lt;title&gt;My First Webpage&lt;/title&gt; &lt;!-- Sets tab title --&gt;
&lt;/head&gt;
&lt;body&gt;
  &lt;h1&gt;Hello, World!&lt;/h1&gt; &lt;!-- Large heading --&gt;
  &lt;p&gt;This is my first webpage. HTML is amazing!&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> Notice how tags come in pairs like <code>&lt;h1&gt;</code> and <code>&lt;/h1&gt;</code>? The opening tag starts it, the closing tag ends it — think of them like bookends holding content together.</p>
                            </div>
                        `,
                        interactiveComponents: [
                            { type: "quiz", questions: htmlLesson1Quiz }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Create a new webpage with a heading “My First Site” and a paragraph describing your favorite food." },
                            { difficulty: "intermediate", task: "Add an image (<img>) and a hyperlink (<a>) to your page." },
                            { difficulty: "hard", task: "Create a personal “About Me” page with a profile image, a short bio, links to 3 favorite websites, and a simple contact form." }
                        ]
                    },
                    {
                        id: "lesson-2-hardware-os",
                        title: "The Stage: Hardware, OS, and Applications",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📘 The Stage: Hardware, OS, and Applications</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~10–15 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">🧭 I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">“Before your code ever reaches the screen, a tiny symphony begins — your computer’s hardware, operating system, and browser work together like instruments in an orchestra. Let’s lift the curtain and see how your HTML actually comes to life.”</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💡 What You Should Know Before Starting</h4>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>You should have completed Lesson 1 (basic idea of HTML).</li>
                                <li>No technical depth required — we’ll use simple metaphors and real-world parallels.</li>
                            </ul>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">⚙️ Setup & Configuration</h4>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">You’ll need:</p>
                            <ol class="list-decimal list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Your <code>index.html</code> file from Lesson 1.</li>
                                <li>A modern browser (Chrome, Firefox, Edge, Safari).</li>
                                <li>Optional: Task Manager / Activity Monitor open — we’ll observe what happens when a page loads.</li>
                            </ol>

                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2070&auto=format&fit=crop" alt="The ecosystem of a webpage: hardware → OS → browser → user interface." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">The ecosystem of a webpage: hardware → OS → browser → user interface.</figcaption>
                            </figure>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">By the end of this lesson, you’ll:</p>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Understand how your computer turns code into visuals.</li>
                                <li>Recognize the roles of CPU, memory, and storage.</li>
                                <li>Learn what browsers actually do behind the scenes.</li>
                                <li>Appreciate how performance depends on this chain.</li>
                            </ul>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💼 Why This Matters</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Knowing the underlying flow helps you debug and optimize later. A web developer who understands the “hardware and OS side” can build faster, more efficient pages — and troubleshoot like a pro.</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">🧠 II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Simple Analogy</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">“Imagine your computer as a restaurant:</p>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Hardware</strong> is the kitchen (where things actually happen).</li>
                                <li>The <strong>operating system</strong> is the chef (managing tasks and tools).</li>
                                <li>The <strong>browser</strong> is the waiter (taking HTML orders and serving them beautifully to the user).”</li>
                            </ul>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Component Breakdown</h4>
                            <ol class="list-decimal list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>CPU</strong> – executes browser tasks and code parsing.</li>
                                <li><strong>RAM</strong> – stores open pages and running scripts.</li>
                                <li><strong>Storage</strong> – holds files and caches.</li>
                                <li><strong>OS</strong> – allocates resources, handles input/output.</li>
                                <li><strong>Browser</strong> – interprets and displays the webpage.</li>
                            </ol>

                            <div class="bg-red-50 dark:bg-slate-800/60 border-l-4 border-red-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm font-semibold text-red-800 dark:text-red-200">❌ Common Misconception: “HTML runs on the internet.”</p>
                                <p class="text-sm text-red-700 dark:text-red-300 mt-1">Actually, HTML is processed locally by your browser — the internet only delivers the file to it.</p>
                            </div>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">⚙️ III. Deep-Dive Mechanics & Behind-the-Scenes</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🔬 What Happens When You Open a Webpage</h4>
                            <ol class="list-decimal list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>You click a link.</li>
                                <li>Browser sends a request to a server via the OS network layer.</li>
                                <li>Server responds with HTML, CSS, JS files.</li>
                                <li>Browser engine (Blink, Gecko, WebKit) parses and constructs DOM.</li>
                                <li>Rendering and painting occur using the GPU.</li>
                            </ol>
                            
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1487058792275-0ad4624ca1c5?q=80&w=2070&auto=format&fit=crop" alt="The journey from click → request → response → render." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">The journey from click → request → response → render.</figcaption>
                            </figure>
                            
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> Every time you refresh, this entire dance repeats — knowing it helps you spot bottlenecks like large image files or inefficient scripts.</p>
                            </div>
                        `,
                        videos: [
                            {
                                src: 'https://www.youtube.com/watch?v=OAx_6-wdslM',
                                localPath: 'assets/videos/lesson2-computer-basics.mp4',
                                poster: 'https://i3.ytimg.com/vi/OAx_6-wdslM/maxresdefault.jpg',
                                caption: 'Visual animation explaining hardware and OS interaction.'
                            },
                            {
                                src: 'https://www.youtube.com/watch?v=SmE4OwHztCc',
                                localPath: 'assets/videos/lesson2-browser-rendering.mp4',
                                poster: 'https://i3.ytimg.com/vi/SmE4OwHztCc/maxresdefault.jpg',
                                caption: 'Detailed walkthrough of HTML parsing and rendering stages.'
                            }
                        ],
                        images: [
                            { src: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=2070&auto=format&fit=crop', alt: 'The ecosystem of a webpage: hardware → OS → browser → user interface.' },
                            { src: 'https://images.unsplash.com/photo-1487058792275-0ad4624ca1c5?q=80&w=2070&auto=format&fit=crop', alt: 'The journey from click → request → response → render.' }
                        ],
                        interactiveComponents: [
                            { 
                                type: "quiz", 
                                questions: [
                                    { question: "What does the OS do for browsers?", options: ["Displays HTML", "Manages resources and hardware access", "Sends emails"], answer: "Manages resources and hardware access" },
                                    { question: "Which component is primarily responsible for drawing pixels to the screen?", options: ["CPU", "RAM", "GPU"], answer: "GPU" },
                                    { question: "Where does HTML code actually 'run' or get processed?", options: ["On the internet server", "Inside the browser on your local device", "Directly on the Operating System"], answer: "Inside the browser on your local device" }
                                ] 
                            }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Open your index.html file and inspect Task Manager/Activity Monitor to observe the browser's CPU activity when you reload the page." },
                            { difficulty: "intermediate", task: "Add three different images (using the <img> tag) to your page, reload it, and observe how the browser's memory usage changes in Task Manager/Activity Monitor." },
                            { difficulty: "hard", task: "Create an 'HTML Performance Lab' page: Add multiple <div> elements, a large image, and a video. Use your browser's Developer Tools (Performance tab) to measure render time and memory usage. Write short notes in a <p> tag about what you observed." }
                        ]
                    }
                ]
            },
            {
                id: "module-2-building-pages",
                title: "Building Your First Pages",
                chapters: [
                    {
                        id: "lesson-3-anatomy-of-a-webpage",
                        title: "Anatomy of a Web Page",
                        content: `
                            <h2 class="text-2xl font-bold mb-4">Code and Content — The Anatomy of a Web Page</h2>
                            <p class="mb-4">If a website were a human, HTML would be its skeleton. Let’s learn how to build that body, bone by bone.</p>
                            <hr class="my-6 border-slate-200 dark:border-slate-700"/>
                            <h3 class="text-xl font-semibold mb-3">Key Building Blocks</h3>
                            <p class="mb-4">Think of HTML as a blueprint for a house:</p>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4">
                                <li><code>&lt;html&gt;</code> → the house itself</li>
                                <li><code>&lt;head&gt;</code> → the storage room for instructions and metadata</li>
                                <li><code>&lt;body&gt;</code> → the visible rooms where people live</li>
                            </ul>
                            <h3 class="text-xl font-semibold mb-3 mt-6">How the Browser Sees It</h3>
                            <p class="mb-4">When you open <code>index.html</code>, the browser:</p>
                            <ol class="list-decimal list-inside space-y-2 mb-4 pl-4">
                                <li>Reads from top to bottom</li>
                                <li>Parses each tag</li>
                                <li>Builds a DOM tree in memory</li>
                                <li>Applies default styling</li>
                                <li>Renders the layout visually</li>
                            </ol>
                        `,
                        interactiveComponents: [
                             { 
                                type: "quiz", 
                                questions: [
                                    { question: "What tag defines the visible page content?", options: ["<body>", "<head>", "<content>"], answer: "<body>" },
                                    { question: "The <head> section holds:", options: ["Visible content", "Metadata and links", "The main article"], answer: "Metadata and links" },
                                    { question: "Missing <!DOCTYPE html> causes:", options: ["The page to load faster", "The browser to enter 'quirks mode'", "A security warning"], answer: "The browser to enter 'quirks mode'" }
                                ] 
                            }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Create a basic page with an <h1> heading, a <p> paragraph, and a <title> element." },
                            { difficulty: "intermediate", task: "Add a <section>, <article>, and <footer> to your page. Include at least one image and one link." }
                        ]
                    },
                    {
                        id: "lesson-4-launching-your-creation",
                        title: "Launching Your Creation",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🚀 Launching Your Creation</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~10 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"You've built your first HTML page - it looks great on your computer. But how do you share it with friends, or even the world? Today, we'll learn the simple steps to launch your creation safely and efficiently. Think of it like finishing a painting - now you need to frame it, display it, and invite others to see it."</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💡 What You Should Know Before Starting</h4>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Completed Lessons 1-3 (HTML basics + developer toolbox).</li>
                                <li>Basic understanding of files and folders.</li>
                                <li>Browser and text editor installed.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">⚙️ Setup & Configuration</h4>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">Organize your project in a folder called <code>about-me-project/</code> with your <code>index.html</code> file inside. Optional tools for this lesson include the 'Live Server' VSCode extension and a GitHub or Netlify account for free hosting.</p>
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1587620962725-abab7fe55159?q=80&w=2070&auto=format&fit=crop" alt="Local and online launch workflow." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">The journey from your computer to the world.</figcaption>
                            </figure>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">By the end of this lesson, you’ll:</p>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Preview your page locally.</li>
                                <li>Learn the steps to publish online.</li>
                                <li>Understand free hosting options.</li>
                                <li>Troubleshoot common launch issues.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💼 Why This Matters</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Coding is only valuable when it's seen. Launching your page teaches deployment, debugging, and introduces the concept of web hosting."</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Simple Analogy</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Local Preview:</strong> Like seeing your painting in your studio.</li>
                                <li><strong>Hosting:</strong> Putting your painting in a gallery.</li>
                                <li><strong>Domain Name:</strong> Giving your painting a permanent address so everyone can visit.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💻 Annotated Code Example</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!-- index.html --&gt;
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;My First Online Page&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1&gt;Welcome to My Website&lt;/h1&gt;
&lt;p&gt;This page is now ready to launch!&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "With this file, you can now preview locally or deploy online. Notice how nothing changes in the code - the difference is where the file lives."</p>
                            </div>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. Deep-Dive Mechanics & Behind-the-Scenes</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">⚙️ How Launch Works</h4>
                            <ol class="list-decimal list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Local Preview:</strong> A tool like Live Server serves files via <code>http://localhost:5500</code>. Changes appear instantly.</li>
                                <li><strong>Hosting Deployment:</strong> You upload files to a server (e.g., Netlify, GitHub Pages). The server listens for requests from the internet and sends your HTML file to visitors' browsers so the page can load.</li>
                            </ol>
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=2072&auto=format&fit=crop" alt="From local file to globally accessible web page." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">From local file to globally accessible web page.</figcaption>
                            </figure>
                        `,
                        videos: [
                            {
                                src: 'https://www.youtube.com/watch?v=R8rmfD9Y5-c',
                                localPath: 'assets/videos/lesson4-github-pages.mp4',
                                poster: 'https://i3.ytimg.com/vi/R8rmfD9Y5-c/maxresdefault.jpg',
                                caption: 'How to Deploy a Website on GitHub Pages by FreeCodeCamp.'
                            },
                            {
                                src: 'https://www.youtube.com/watch?v=71wSzpLyW9k',
                                localPath: 'assets/videos/lesson4-netlify.mp4',
                                poster: 'https://i3.ytimg.com/vi/71wSzpLyW9k/maxresdefault.jpg',
                                caption: 'Deploy Websites for Free Using Netlify by Tech With Tim.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "What is a localhost URL example?", options: ["http://127.0.0.1:5500", "www.google.com", "ftp://localhost"], answer: "http://127.0.0.1:5500" },
                                { question: "What does hosting do?", options: ["Stores files on a public server", "Edits your code automatically", "Previews your CSS"], answer: "Stores files on a public server" },
                                { question: "What is GitHub Pages used for?", options: ["Editing JavaScript", "Free static website hosting", "Browser debugging"], answer: "Free static website hosting" },
                                { question: "What is a common deployment issue?", options: ["Broken links or missing images", "The page loads too fast", "The HTML code has errors"], answer: "Broken links or missing images" },
                                { question: "Why should you preview your site locally first?", options: ["It's just for fun", "To check that everything works before publishing", "To avoid writing any code"], answer: "To check that everything works before publishing" },
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Preview your index.html locally with Live Server." },
                            { difficulty: "intermediate", task: "Deploy your first HTML page to GitHub Pages." },
                            { difficulty: "hard", task: "Use Netlify to deploy your page and connect a custom free domain." },
                        ]
                    },
                    {
                        id: "lesson-5-images",
                        title: "Working with Images",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🖼️ Working with Images</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~10 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Have you ever visited a webpage with beautiful pictures and wondered how they got there so perfectly? Today, we'll learn how to add images, control their size, and make them responsive - making your page visually appealing. Think of images as the decoration on your digital house - they make your site inviting and engaging."</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">⚙️ Setup & Configuration</h4>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">Inside your project folder, create a new folder named <code>images/</code>. Place any sample images you want to use (like <code>profile.jpg</code> or <code>banner.png</code>) inside this new folder to keep your project organized.</p>
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1544256718-3b62ff04b2cb?q=80&w=2070&auto=format&fit=crop" alt="Organize images inside a dedicated folder." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">Organize images inside a dedicated folder for cleaner projects.</figcaption>
                            </figure>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">By the end of this lesson, you’ll be able to:</p>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Use the <code>&lt;img&gt;</code> tag to embed images.</li>
                                <li>Add <code>alt</code> attributes for accessibility.</li>
                                <li>Control image size with <code>width</code> and <code>height</code> attributes.</li>
                                <li>Make images responsive using the <code>&lt;picture&gt;</code> element.</li>
                                <li>Understand the importance of image optimization for performance.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💼 Why This Matters</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Images enhance user experience and engagement, but unoptimized images can slow your site down. Learning to embed them properly ensures your site is accessible, responsive, and loads quickly."</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Simple Analogy</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>HTML <code>&lt;img&gt;</code> tag:</strong> The picture frame.</li>
                                <li><strong><code>src</code> attribute:</strong> The path to the picture.</li>
                                <li><strong><code>alt</code> attribute:</strong> A description for people who can’t see the image (essential for accessibility).</li>
                                <li><strong>CSS:</strong> Adjusts size and style, like resizing the frame.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💻 Annotated Code Example</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;Image Demo&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1&gt;My Profile Picture&lt;/h1&gt;
&lt;img src="images/profile.jpg" alt="Profile Picture" width="300"&gt;

&lt;h2&gt;Responsive Banner&lt;/h2&gt;
&lt;picture&gt;
  &lt;source media="(max-width: 600px)" srcset="images/banner-small.png"&gt;
  &lt;source media="(min-width: 601px)" srcset="images/banner-large.png"&gt;
  &lt;img src="images/banner-large.png" alt="Website Banner"&gt;
&lt;/picture&gt;
&lt;/body&gt;
&lt;/html&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "Notice the <code>&lt;picture&gt;</code> element: it allows you to serve different images based on screen size, making your page responsive."</p>
                            </div>
                        `,
                        videos: [
                            {
                                src: 'https://www.youtube.com/watch?v=0HlNDRrGDA4',
                                localPath: 'assets/videos/lesson5-html-images.mp4',
                                poster: 'https://i3.ytimg.com/vi/0HlNDRrGDA4/maxresdefault.jpg',
                                caption: 'HTML Images for Beginners by FreeCodeCamp.'
                            },
                            {
                                src: 'https://www.youtube.com/watch?v=0OHL9Pgr5-s',
                                localPath: 'assets/videos/lesson5-responsive-images.mp4',
                                poster: 'https://i3.ytimg.com/vi/0OHL9Pgr5-s/maxresdefault.jpg',
                                caption: 'Responsive Images Tutorial by LearnWebCode.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "Which tag embeds images?", options: ["<img>", "<image>", "<pic>"], answer: "<img>" },
                                { question: "What is the purpose of the 'alt' attribute?", options: ["To style the image", "For accessibility and SEO", "To add an animation"], answer: "For accessibility and SEO" },
                                { question: "How can you make images responsive?", options: ["Using only the <img> tag", "With the <picture> element or CSS", "With an HTML comment"], answer: "With the <picture> element or CSS" },
                                { question: "Which are recommended image file formats for the web?", options: ["BMP, TIFF", "PNG, JPG, SVG", "DOCX, PDF"], answer: "PNG, JPG, SVG" },
                                { question: "Why is it important to optimize images?", options: ["For faster page load times", "For better SEO ranking", "All of the above"], answer: "All of the above" },
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Embed one profile image with a proper alt attribute." },
                            { difficulty: "intermediate", task: "Add a banner image and make it responsive using <picture>." },
                            { difficulty: "hard", task: "Optimize images using a free tool (like TinyPNG) and implement them on your webpage." },
                        ]
                    },
                    {
                        id: "lesson-6-lists",
                        title: "Structuring with Lists",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📜 Structuring with Lists (ul, ol, li)</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~10 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Ever visited a website where steps, ingredients, or features were listed neatly? That's HTML lists at work. Today, we'll master lists - the secret behind well-organized content. Think of lists as shelves where every item has its place - clean, readable, and accessible."</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Create unordered (<code>&lt;ul&gt;</code>) and ordered (<code>&lt;ol&gt;</code>) lists.</li>
                                <li>Nest lists for sub-items.</li>
                                <li>Apply attributes like <code>type</code>, <code>start</code>, and <code>reversed</code>.</li>
                                <li>Use lists for navigation menus and steps.</li>
                            </ul>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Simple Analogy</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong><code>&lt;ul&gt;</code>:</strong> A grocery list with bullets - no particular order.</li>
                                <li><strong><code>&lt;ol&gt;</code>:</strong> Step-by-step instructions - numbered.</li>
                                <li><strong><code>&lt;li&gt;</code>:</strong> Each individual item on the list.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💻 Annotated Code Example</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;Lists Demo&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1&gt;My Favorite Fruits&lt;/h1&gt;
&lt;ul&gt;
  &lt;li&gt;Apple&lt;/li&gt;
  &lt;li&gt;Banana&lt;/li&gt;
  &lt;li&gt;Cherry&lt;/li&gt;
&lt;/ul&gt;

&lt;h2&gt;Steps to Make Tea&lt;/h2&gt;
&lt;ol&gt;
  &lt;li&gt;Boil water&lt;/li&gt;
  &lt;li&gt;Add tea leaves&lt;/li&gt;
  &lt;li&gt;Steep for 3 minutes&lt;/li&gt;
&lt;/ol&gt;

&lt;h3&gt;Nested Example&lt;/h3&gt;
&lt;ul&gt;
  &lt;li&gt;Fruits
    &lt;ul&gt;
      &lt;li&gt;Apple&lt;/li&gt;
      &lt;li&gt;Banana&lt;/li&gt;
    &lt;/ul&gt;
  &lt;/li&gt;
&lt;/ul&gt;
&lt;/body&gt;
&lt;/html&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "Notice the nested <code>&lt;ul&gt;</code> inside an <code>&lt;li&gt;</code> - it's perfect for categories with sub-items."</p>
                            </div>
                        `,
                        videos: [
                            {
                                src: 'https://www.youtube.com/watch?v=ao6I6Nfwr2E',
                                localPath: 'assets/videos/lesson6-html-lists.mp4',
                                poster: 'https://i3.ytimg.com/vi/ao6I6Nfwr2E/maxresdefault.jpg',
                                caption: 'HTML Lists Tutorial for Beginners by FreeCodeCamp.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "Which tag is for an unordered list?", options: ["<ol>", "<ul>", "<li>"], answer: "<ul>" },
                                { question: "Which tag is for an ordered list?", options: ["<ul>", "<ol>", "<li>"], answer: "<ol>" },
                                { question: "Which tag contains the individual list items?", options: ["<li>", "<ol>", "<ul>"], answer: "<li>" },
                                { question: `How do you start a numbered list at 5?`, options: [`<ol start="5">`, `<ul start="5">`, `<li start="5">`], answer: `<ol start="5">` },
                                { question: "How do you create a nested list?", options: ["Put an <li> inside another <li>", "Put a <ul> or <ol> inside an <li>", "Put a <p> tag inside a <ul>"], answer: "Put a <ul> or <ol> inside an <li>" },
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Create an unordered list of your 5 favorite foods." },
                            { difficulty: "intermediate", task: "Create an ordered list of the 3 main steps to complete a simple task you know." },
                            { difficulty: "hard", task: "Create a nested list: list two categories, and under each category, list at least two specific items." },
                        ]
                    },
                    {
                        id: "lesson-7-tables",
                        title: "Organizing Data with Tables",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📊 Organizing Data with Tables</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~12 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Have you ever looked at a webpage and seen a neat schedule, price list, or data table and wondered how it was organized? That's HTML tables in action. Today, we'll master tables to display information clearly. Think of tables as grids in a spreadsheet - every piece of data has a precise location."</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Create basic tables with <code>&lt;table&gt;</code>, <code>&lt;tr&gt;</code>, and <code>&lt;td&gt;</code>.</li>
                                <li>Add headings using <code>&lt;th&gt;</code>.</li>
                                <li>Merge cells with <code>colspan</code> and <code>rowspan</code>.</li>
                                <li>Add captions with <code>&lt;caption&gt;</code>.</li>
                            </ul>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Simple Analogy</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong><code>&lt;table&gt;</code>:</strong> The entire spreadsheet.</li>
                                <li><strong><code>&lt;tr&gt;</code>:</strong> A row of data.</li>
                                <li><strong><code>&lt;td&gt;</code>:</strong> A standard table cell.</li>
                                <li><strong><code>&lt;th&gt;</code>:</strong> A header cell (bold and centered by default).</li>
                                <li><strong><code>&lt;caption&gt;</code>:</strong> A title for the table.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💻 Annotated Code Example</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;Table Demo&lt;/title&gt;
&lt;style&gt; 
  table, th, td { border: 1px solid black; border-collapse: collapse; padding: 8px; }
  caption { font-weight: bold; margin-bottom: 5px; }
&lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;table&gt;
  &lt;caption&gt;Monthly Expenses&lt;/caption&gt;
  &lt;tr&gt;
    &lt;th&gt;Month&lt;/th&gt;
    &lt;th&gt;Rent&lt;/th&gt;
    &lt;th&gt;Groceries&lt;/th&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td&gt;January&lt;/td&gt;
    &lt;td&gt;$500&lt;/td&gt;
    &lt;td&gt;$200&lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td&gt;February&lt;/td&gt;
    &lt;td&gt;$500&lt;/td&gt;
    &lt;td&gt;$220&lt;/td&gt;
  &lt;/tr&gt;
&lt;/table&gt;
&lt;/body&gt;
&lt;/html&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "The <code>&lt;caption&gt;</code> tag is important! It describes the table's content, which is crucial for accessibility and clarity."</p>
                            </div>
                        `,
                        videos: [
                            {
                                src: 'https://www.youtube.com/watch?v=tr8rgPxjEos',
                                localPath: 'assets/videos/lesson7-html-tables.mp4',
                                poster: 'https://i3.ytimg.com/vi/tr8rgPxjEos/maxresdefault.jpg',
                                caption: 'HTML Tables for Beginners by FreeCodeCamp.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "Which tag defines a table row?", options: ["<td>", "<tr>", "<th>"], answer: "<tr>" },
                                { question: "How do you merge cells horizontally across columns?", options: ["rowspan", "colspan", "merge"], answer: "colspan" },
                                { question: "What is the purpose of the <caption> tag?", options: ["To provide a title for the table", "To style the table", "To add a border"], answer: "To provide a title for the table" },
                                { question: "Which tag is used for a header cell?", options: ["<th>", "<td>", "<tr>"], answer: "<th>" },
                                { question: "Is it a good practice to use tables for page layout?", options: ["Yes, it's the modern way", "No, CSS should be used for layout", "Only for simple pages"], answer: "No, CSS should be used for layout" },
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Create a 3x3 table with headings (Name, Age, City) and some sample data." },
                            { difficulty: "intermediate", task: "Add a <caption> to your table. Then, merge two columns in one of the data rows using colspan." },
                            { difficulty: "hard", task: "Create a weekly schedule table. Use rowspan to make a single cell span across multiple time slots (e.g., a 2-hour meeting)." },
                        ]
                    },
                    {
                        id: "lesson-8-forms",
                        title: "Creating Interactive Forms",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📝 Creating Interactive Forms</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~15 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Ever signed up for a newsletter, submitted a contact form, or left a comment? Those interactions are powered by HTML forms. Today, we'll learn how to create forms that collect data efficiently. Think of a form as the bridge between the user and your website."</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Create basic forms with the <code>&lt;form&gt;</code> tag.</li>
                                <li>Add various input elements like <code>&lt;input&gt;</code>, <code>&lt;textarea&gt;</code>, and <code>&lt;select&gt;</code>.</li>
                                <li>Use attributes like <code>type</code>, <code>name</code>, <code>placeholder</code>, and <code>required</code>.</li>
                                <li>Implement submit buttons and understand form actions.</li>
                            </ul>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Simple Analogy</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong><code>&lt;form&gt;</code>:</strong> The envelope for user data.</li>
                                <li><strong><code>&lt;input&gt;</code>:</strong> A field for text, a checkbox, or a radio button.</li>
                                <li><strong><code>&lt;textarea&gt;</code>:</strong> A multi-line text box for longer messages.</li>
                                <li><strong><code>&lt;select&gt;</code>:</strong> A dropdown menu for choices.</li>
                                <li><strong><code>&lt;button&gt;</code>:</strong> A button to submit the form.</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💻 Annotated Code Example</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;Form Demo&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;h1&gt;Contact Us&lt;/h1&gt;
&lt;form action="/submit-form" method="POST"&gt;
  &lt;label for="name"&gt;Name:&lt;/label&gt;&lt;br&gt;
  &lt;input type="text" id="name" name="name" placeholder="Your Name" required&gt;&lt;br&gt;&lt;br&gt;

  &lt;label for="email"&gt;Email:&lt;/label&gt;&lt;br&gt;
  &lt;input type="email" id="email" name="email" placeholder="you@example.com" required&gt;&lt;br&gt;&lt;br&gt;

  &lt;label for="message"&gt;Message:&lt;/label&gt;&lt;br&gt;
  &lt;textarea id="message" name="message" rows="4" required&gt;&lt;/textarea&gt;&lt;br&gt;&lt;br&gt;

  &lt;button type="submit"&gt;Send Message&lt;/button&gt;
&lt;/form&gt;
&lt;/body&gt;
&lt;/html&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "The <code>required</code> attribute is a simple way to do basic validation—it prevents the form from being submitted if a field is empty. Also, always use the <code>&lt;label&gt;</code> tag for accessibility!"</p>
                            </div>
                        `,
                        videos: [
                            {
                                src: 'https://www.youtube.com/watch?v=fNcJuPIZ2WE',
                                localPath: 'assets/videos/lesson8-html-forms.mp4',
                                poster: 'https://i3.ytimg.com/vi/fNcJuPIZ2WE/maxresdefault.jpg',
                                caption: 'HTML Forms Tutorial for Beginners by FreeCodeCamp.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "Which tag is the main container for a form?", options: ["<input>", "<form>", "<textarea>"], answer: "<form>" },
                                { question: "What input type should be used for an email address field?", options: ["text", "email", "password"], answer: "email" },
                                { question: "What does the 'required' attribute do?", options: ["Makes an input field mandatory", "Hides the input field", "Changes the font"], answer: "Makes an input field mandatory" },
                                { question: "Which element is used for a multi-line text input?", options: ["<input type='text'>", "<textarea>", "<select>"], answer: "<textarea>" },
                                { question: "Which tag creates a dropdown list?", options: ["<select>", "<list>", "<dropdown>"], answer: "<select>" },
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Create a simple form with a name input, an email input, and a submit button." },
                            { difficulty: "intermediate", task: "Add a <textarea> for messages and a <select> dropdown for country selection. Make all fields required." },
                            { difficulty: "hard", task: "Create a complete contact form with text inputs, a textarea, radio buttons for a topic (e.g., 'General Inquiry', 'Support'), a checkbox for 'I agree to the terms', and a submit button." },
                        ]
                    },
                    {
                        id: "lesson-9-code-organization",
                        title: "Comments & Code Organization",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🧹 Comments and Code Organization</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~8 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Ever opened someone else's code and felt lost? Or revisited your own project months later and couldn't figure out what you wrote? Comments and organization are your secret weapons to clarity. Think of them as sticky notes for your future self."</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🧩 Learning Roadmap</h4>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Add single-line and multi-line comments.</li>
                                <li>Use consistent indentation and spacing.</li>
                                <li>Understand why organization matters for collaboration.</li>
                            </ul>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Core Definitions & Fundamental Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💻 Annotated Code Example</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
  &lt;title&gt;About Me&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;

  &lt;!-- Header Section --&gt;
  &lt;header&gt;
    &lt;h1&gt;Welcome to My Page&lt;/h1&gt;
    &lt;!-- Navigation menu goes here --&gt;
    &lt;nav&gt;
      ...
    &lt;/nav&gt;
  &lt;/header&gt;

  &lt;!-- Main Content --&gt;
  &lt;main&gt;
    &lt;section&gt;
      &lt;h2&gt;About Me&lt;/h2&gt;
      &lt;p&gt;Hi, I'm learning web development!&lt;/p&gt;
    &lt;/section&gt;
  &lt;/main&gt;

&lt;/body&gt;
&lt;/html&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "Notice how each major section has a comment. Even simple projects benefit from this. Proper indentation also makes the nesting of elements clear at a glance. Clean code is professional code!"</p>
                            </div>
                        `,
                        videos: [
                           {
                                src: 'https://www.youtube.com/watch?v=HcOc7P5BMi4',
                                localPath: 'assets/videos/lesson9-html-structure.mp4',
                                poster: 'https://i3.ytimg.com/vi/HcOc7P5BMi4/maxresdefault.jpg',
                                caption: 'Semantic HTML Explained by Kevin Powell.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "What is the correct syntax for an HTML comment?", options: ["<!-- -->", "<comment></comment>", "//"], answer: "<!-- -->" },
                                { question: "Does indentation affect how the browser renders the page?", options: ["Yes", "No", "Only in tables"], answer: "No" },
                                { question: "Why is organizing files into separate folders (e.g., css/, images/) a good practice?", options: ["Improves readability and maintenance", "Makes the website render faster", "It's required for HTML to work"], answer: "Improves readability and maintenance" },
                                { question: "What is the primary purpose of adding comments to your code?", options: ["As notes for developers to understand the code", "To add new features", "To style elements"], answer: "As notes for developers to understand the code" },
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Add comments to an existing HTML file to label the header, main content, and footer sections." },
                            { difficulty: "intermediate", task: "Take an unformatted HTML file and apply consistent indentation to all nested elements." },
                        ]
                    },
                    {
                        id: "lesson-10-file-structure",
                        title: "File Structure for Web Projects",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📁 File Structure for Web Projects</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner-Intermediate | Duration: ~10 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"A well-organized file structure is like a roadmap for you and anyone else working on your project. It prevents chaos and makes your work scalable and professional."</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💡 Learning Outcomes</h4>
                            <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Create a scalable folder structure.</li>
                                <li>Organize HTML, CSS, JS, and media files logically.</li>
                                <li>Reference files correctly with relative paths.</li>
                            </ul>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Recommended Folder Structure</h3>
                            <pre class="bg-slate-100 dark:bg-slate-800 p-4 rounded-lg text-sm"><code>personal-website/
├── index.html
├── about.html
├── contact.html
├── assets/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
│       ├── logo.png
│       └── gallery/
│           └── photo1.jpg
└── README.md
</code></pre>
                            <p class="mt-4 text-slate-600 dark:text-slate-300">Key Points: <code>index.html</code> is the homepage. All assets (CSS, JS, images) are grouped in an <code>assets/</code> folder. Subfolders provide even more organization.</p>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. Linking Files Correctly</h3>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">Use relative paths to link your assets from your HTML files.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!-- Linking CSS --&gt;
&lt;link rel="stylesheet" href="assets/css/style.css"&gt;

&lt;!-- Referencing an Image --&gt;
&lt;img src="assets/images/logo.png" alt="Site Logo"&gt;

&lt;!-- Linking JavaScript --&gt;
&lt;script src="assets/js/main.js"&gt;&lt;/script&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "This structure is professional and scalable. It keeps your code clean and makes it easy to find any file you need, which is critical as projects grow."</p>
                            </div>
                        `,
                        videos: [
                           {
                                src: 'https://www.youtube.com/watch?v=6c7bP1KKp5Y',
                                localPath: '',
                                poster: 'https://i3.ytimg.com/vi/6c7bP1KKp5Y/maxresdefault.jpg',
                                caption: 'Organizing Web Project Files by Traversy Media.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "Where should CSS files typically be stored?", options: ["In the root folder", "In an assets/css/ folder", "In an assets/images/ folder"], answer: "In an assets/css/ folder" },
                                { question: "What is the correct `src` for a JS file named 'main.js' inside an 'assets/js/' folder?", options: ["main.js", "js/main.js", "assets/js/main.js"], answer: "assets/js/main.js" },
                                { question: "Why use subfolders for images (e.g., 'gallery/')?", options: ["It's just for decoration", "For better organization and scalability", "HTML requires it"], answer: "For better organization and scalability" },
                                { question: "What is a README.md file commonly used for?", options: ["Website styling", "A project description for collaborators", "JavaScript logic"], answer: "A project description for collaborators" }
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Create a basic folder structure for a one-page project with index.html and assets/css/style.css." },
                            { difficulty: "intermediate", task: "Organize a 3-page website (index.html, about.html, contact.html) with CSS, JS, and images in separate asset folders." },
                            { difficulty: "hard", task: "Build a full project folder for your 'About Me' page with multiple CSS files, multiple JS files, and a nested image gallery folder. Ensure all links work correctly." }
                        ]
                    },
                    {
                        id: "lesson-11-whats-next",
                        title: "What's Next? Transition to HTML5 Semantic Web",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🚀 What's Next? Transition to HTML5 Semantic Web</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Beginner | Duration: ~10 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"You've built pages, added images, lists, and forms. Now it's time to level up. The modern web demands semantic HTML5 for better accessibility, SEO, and maintainability."</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💡 Learning Outcomes</h4>
                             <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Understand the benefits of semantic HTML5.</li>
                                <li>Identify key semantic elements and their purposes.</li>
                                <li>Plan your next project using HTML5 best practices.</li>
                            </ul>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Why Semantic HTML5 Matters</h3>
                             <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Readability:</strong> Humans and machines can understand your page structure.</li>
                                <li><strong>Accessibility:</strong> Screen readers rely on semantic tags like <code>&lt;nav&gt;</code> and <code>&lt;main&gt;</code>.</li>
                                <li><strong>SEO:</strong> Search engines prioritize well-structured, semantic content.</li>
                                <li><strong>Maintainability:</strong> Cleaner code is easier to update and scale.</li>
                            </ul>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. Practical Example: Updating Your Page</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Before (Classic HTML):</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;div id="header"&gt;...&lt;/div&gt;
&lt;div id="nav"&gt;...&lt;/div&gt;
&lt;div id="content"&gt;...&lt;/div&gt;
&lt;div id="footer"&gt;...&lt;/div&gt;
</code></pre>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">After (HTML5 Semantic):</h4>
                             <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;header&gt;...&lt;/header&gt;
&lt;nav&gt;...&lt;/nav&gt;
&lt;main&gt;
  &lt;section id="bio"&gt;...&lt;/section&gt;
&lt;/main&gt;
&lt;footer&gt;...&lt;/footer&gt;
</code></pre>
                             <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "This transition makes your code instantly understandable, more accessible, and better for SEO. It's a hallmark of a professional developer."</p>
                            </div>
                        `,
                        videos: [
                           {
                                src: 'https://www.youtube.com/watch?v=0Zx1lCjq2sE',
                                localPath: '',
                                poster: 'https://i3.ytimg.com/vi/0Zx1lCjq2sE/maxresdefault.jpg',
                                caption: 'Semantic HTML5 Tutorial by Traversy Media.'
                            }
                        ],
                        interactiveComponents: [
                            { type: "quiz", questions: [
                                { question: "Which tag defines the main, unique content of a page?", options: ["<main>", "<section>", "<div>"], answer: "<main>" },
                                { question: "What tag is most suitable for a sidebar or extra, tangential content?", options: ["<aside>", "<article>", "<footer>"], answer: "<aside>" },
                                { question: "How many <main> tags should a page have?", options: ["Multiple", "Only one", "None"], answer: "Only one" },
                                { question: "Why is semantic HTML5 important?", options: ["For accessibility, SEO, and maintainability", "For random styling", "For faster loading times"], answer: "For accessibility, SEO, and maintainability" },
                                { question: "What non-semantic tag is often replaced by tags like <header>, <section>, or <nav>?", options: ["<p>", "<span>", "<div>"], answer: "<div>" }
                            ] }
                        ],
                        codeChallenges: [
                            { difficulty: "easy", task: "Identify <div> elements in your 'About Me' page and suggest which semantic replacements like <header>, <main>, <section>, or <footer> would be appropriate." },
                            { difficulty: "intermediate", task: "Actively replace the generic <div>s in your project with the correct semantic tags." }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: "html5-semantic-web",
        title: "HTML5 and Semantic Web",
        description: "Learn to write structured, meaningful, and accessible code using modern HTML5 standards. Go beyond the basics and build professional-grade web pages.",
        imageUrl: "https://images.unsplash.com/photo-1621839673705-66174b1c8907?q=80&w=2064&auto=format&fit=crop",
        level: "Intermediate",
        modules: [
            {
                id: "module-1-intro-to-html5",
                title: "Introduction to HTML5",
                chapters: [
                    {
                        id: "lesson-1-intro-to-html5",
                        title: "Introduction to HTML5",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📜 Introduction to HTML5</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~12 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction & Setup</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Imagine the web before HTML5 - full of <code>&lt;div&gt;</code>s, table-based layouts, and Flash videos. Now think of the modern web—videos that play natively, responsive designs, and clear structure. That's HTML5 in action.</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💡 What You Should Know Before Starting</h4>
                             <ul class="list-disc list-inside space-y-1 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Basic HTML structure (<code>&lt;html&gt;</code>, <code>&lt;head&gt;</code>, <code>&lt;body&gt;</code>)</li>
                                <li>How to create links, lists, images, and forms</li>
                                <li>How to organize files into folders</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">💼 Why This Matters</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"HTML5 isn't just an update. It's a philosophy—clean, meaningful, accessible, code that makes your site work for everyone."</p>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. What Is HTML5?</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">HTML5 is the fifth major version of HTML. It defines how web pages are structured, presented, and interacted with—combining semantics, multimedia, and API integration. It replaced many outdated methods:</p>
                             <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li>Flash animations → <code>&lt;video&gt;</code> and <code>&lt;audio&gt;</code></li>
                                <li><code>&lt;table&gt;</code> layouts → Semantic structure</li>
                                <li>Browser plugins → Native support for graphics and media</li>
                            </ul>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. From Old HTML to HTML5</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Before (HTML4 style):</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;div id="top"&gt;Welcome&lt;/div&gt;
&lt;div id="menu"&gt;Home | About | Contact&lt;/div&gt;
&lt;div id="content"&gt;Page content goes here.&lt;/div&gt;
&lt;div id="bottom"&gt;Copyright (c) 2025&lt;/div&gt;</code></pre>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">After (HTML5 style):</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;header&gt;Welcome&lt;/header&gt;
&lt;nav&gt;Home | About | Contact&lt;/nav&gt;
&lt;main&gt;Page content goes here.&lt;/main&gt;
&lt;footer&gt;Copyright (c) 2025&lt;/footer&gt;</code></pre>
                             <p class="mb-4 text-slate-600 dark:text-slate-300">The HTML5 version is cleaner, easier to read, and more accessible to screen readers and search engines.</p>
                             
                             <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                             <h3 class="text-xl font-semibold mb-4">IV. Semantic Meaning: The Core of HTML5</h3>
                             <p class="mb-4 text-slate-600 dark:text-slate-300">A semantic element clearly describes its meaning to both the browser and the developer. For example, <code>&lt;header&gt;</code> is the top section, and <code>&lt;nav&gt;</code> is for navigation links.</p>
                             <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1558655146-364adaf1fcc9?q=80&w=2070&auto=format&fit=crop" alt="A semantic HTML5 page layout diagram" class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">A semantic HTML5 page layout showing header, nav, main, and footer.</figcaption>
                            </figure>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=UB1O30fR-EE', localPath: '', poster: 'https://i3.ytimg.com/vi/UB1O30fR-EE/maxresdefault.jpg', caption: 'HTML5 Crash Course by Traversy Media' },
                            { src: 'https://www.youtube.com/watch?v=Gxh9YbV9VAE', localPath: '', poster: 'https://i3.ytimg.com/vi/Gxh9YbV9VAE/maxresdefault.jpg', caption: 'Semantic HTML Explained by Kevin Powell' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "What is a key purpose of HTML5?", options: ["To style websites with colors", "To add structure and meaning to content", "To add animations"], answer: "To add structure and meaning to content" },
                            { question: "Which element defines navigation links?", options: ["<nav>", "<links>", "<menu>"], answer: "<nav>" },
                            { question: "HTML5 replaced Flash for video with which tag?", options: ["<object>", "<video>", "<embed>"], answer: "<video>" },
                            { question: "What tag represents the main, unique content of a page?", options: ["<content>", "<main>", "<body>"], answer: "<main>" },
                            { question: "Which tag defines a thematic section of related content?", options: ["<div>", "<section>", "<span>"], answer: "<section>" }
                        ]}],
                        codeChallenges: [{ difficulty: 'easy', task: 'Create an HTML page using the basic semantic layout: <header>, <nav>, <main>, and <footer>. Add a title in the header and a copyright notice in the footer.' }]
                    },
                    {
                        id: "lesson-2-document-structure",
                        title: "HTML5 Document Structure & Doctype",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📄 HTML5 Document Structure & Doctype Declaration</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~12 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Imagine giving a book to someone without a cover, title, or chapters—they'd struggle to read it. A web page without a proper document structure feels the same way to a browser. HTML5 provides a clear blueprint that browsers instantly recognize.</p>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. HTML5 Boilerplate Example</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Here's the simplest valid HTML5 structure:</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
  &lt;meta charset="UTF-8"&gt;
  &lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;
  &lt;meta name="description" content="An example of a clean HTML5 document structure."&gt;
  &lt;title&gt;My HTML5 Page&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
  &lt;h1&gt;Welcome to My HTML5 Page&lt;/h1&gt;
  &lt;p&gt;This page follows the correct document structure.&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Key Sections Explained</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><code>&lt;!DOCTYPE html&gt;</code>: Tells the browser this is an HTML5 document. Without it, browsers may use "quirks mode," leading to inconsistent layouts.</li>
                                <li><code>&lt;html lang="en"&gt;</code>: The root element. The <code>lang</code> attribute helps with accessibility and search engines.</li>
                                <li><code>&lt;head&gt;</code>: Contains metadata (invisible to users), such as the page title, character set, and links to stylesheets.</li>
                                <li><code>&lt;body&gt;</code>: Contains all the visible content of the page.</li>
                            </ul>

                             <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Important <code>&lt;meta&gt;</code> Tags</h4>
                             <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><code>&lt;meta charset="UTF-8"&gt;</code>: Ensures special characters (like © or é) display correctly.</li>
                                <li><code>&lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;</code>: Crucial for making pages responsive and look good on mobile devices.</li>
                             </ul>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=y2649w3y_g0', localPath: '', poster: 'https://i3.ytimg.com/vi/y2649w3y_g0/maxresdefault.jpg', caption: 'Basic HTML Structure by Kevin Powell.' },
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                             { question: "What does <!DOCTYPE html> do?", options: ["Adds a title to the page", "Declares the document as HTML5", "Links a CSS file"], answer: "Declares the document as HTML5" },
                             { question: "Which tag contains the visible page content?", options: ["<head>", "<html>", "<body>"], answer: "<body>" },
                             { question: "Which meta tag is essential for making a page responsive?", options: ["charset", "description", "viewport"], answer: "viewport" },
                             { question: "What kind of information goes in the <head> section?", options: ["The main page content", "Metadata and links to external files", "Images and videos"], answer: "Metadata and links to external files" },
                             { question: "Which tag is the root of an HTML page?", options: ["<html>", "<root>", "<main>"], answer: "<html>" },
                        ]}],
                        codeChallenges: [{ difficulty: 'easy', task: 'Create a valid index.html file with the correct doctype, head, and body structure. Include a title and the two essential meta tags (charset and viewport).' }]
                    },
                    {
                        id: "lesson-3-semantic-elements",
                        title: "HTML5 Semantic Elements Deep Dive",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🏗️ HTML5 Semantic Elements Deep Dive</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~15 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Imagine a library where every book is scattered randomly—no sections, no labels. That's a website without semantic HTML. These elements give every page a clear 'table of contents' for browsers, search engines, and assistive technologies.</p>
                             <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Tip:</strong> "Think of <code>&lt;section&gt;</code> as chapters in a book, <code>&lt;article&gt;</code> as pages within those chapters, and <code>&lt;main&gt;</code> as the story itself."</p>
                            </div>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. Core Semantic Elements</h3>
                            <ul class="list-disc list-inside space-y-3 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><code>&lt;header&gt;</code>: Introductory content. Can be used for the whole page or for an article.</li>
                                <li><code>&lt;nav&gt;</code>: Navigation links.</li>
                                <li><code>&lt;main&gt;</code>: The main, unique content of the page. <strong>There should only be one per page.</strong></li>
                                <li><code>&lt;section&gt;</code>: A thematic grouping of content (e.g., "About Us", "Services").</li>
                                <li><code>&lt;article&gt;</code>: A self-contained piece of content that could stand on its own (e.g., a blog post, a news story).</li>
                                <li><code>&lt;aside&gt;</code>: Tangential content, like a sidebar with related links.</li>
                                <li><code>&lt;footer&gt;</code>: The bottom of a page or section, containing info like copyright or contact details.</li>
                            </ul>

                             <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. Example: Blog Homepage</h3>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;body&gt;
  &lt;header&gt;
    &lt;h1&gt;My Blog&lt;/h1&gt;
    &lt;nav&gt; ... &lt;/nav&gt;
  &lt;/header&gt;

  &lt;main&gt;
    &lt;article&gt;
      &lt;h2&gt;Post Title 1&lt;/h2&gt;
      &lt;p&gt;This is the first blog post content.&lt;/p&gt;
    &lt;/article&gt;
    &lt;article&gt;
      &lt;h2&gt;Post Title 2&lt;/h2&gt;
      &lt;p&gt;This is the second blog post content.&lt;/p&gt;
    &lt;/article&gt;
  &lt;/main&gt;

  &lt;aside&gt;
    &lt;h3&gt;About Me&lt;/h3&gt;
    &lt;p&gt;Short bio and links to social profiles.&lt;/p&gt;
  &lt;/aside&gt;

  &lt;footer&gt;
    &lt;p&gt;(c) 2025 My Semantic Blog&lt;/p&gt;
  &lt;/footer&gt;
&lt;/body&gt;</code></pre>
                        `,
                        videos: [
                           { src: 'https://www.youtube.com/watch?v=HcOc7P5BMi4', localPath: '', poster: 'https://i3.ytimg.com/vi/HcOc7P5BMi4/maxresdefault.jpg', caption: 'HTML5 Semantic Elements by Kevin Powell' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "What is the purpose of the <main> tag?", options: ["Footer information", "The primary, unique content of the page", "Navigation links"], answer: "The primary, unique content of the page" },
                            { question: "Which tag is best for a self-contained blog post?", options: ["<section>", "<article>", "<aside>"], answer: "<article>" },
                            { question: "Where should <nav> typically appear?", options: ["Only in the header", "Anywhere there are primary navigation links", "Only in the footer"], answer: "Anywhere there are primary navigation links" },
                            { question: "How many <main> tags are allowed per page?", options: ["Only one", "Two", "As many as you need"], answer: "Only one" },
                            { question: "What is the <aside> tag used for?", options: ["The main content", "Sidebar or tangentially related info", "The footer"], answer: "Sidebar or tangentially related info" },
                        ]}],
                        codeChallenges: [
                            { difficulty: 'intermediate', task: 'Build a page layout for a blog post. Use <header> for the post title and author, <article> to wrap the content, and <aside> for related articles.' },
                            { difficulty: 'hard', task: 'Create a 2-page website (Home and About). The Home page should use <main> and multiple <section> elements. The About page should use <main> and an <article> for a bio. Both pages must share a common <header> and <footer>.' }
                        ]
                    },
                    {
                        id: "lesson-4-inline-vs-block",
                        title: "Inline vs Block-Level Elements",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🧱 Inline vs Block-Level Elements</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~12 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Core Definitions</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Understanding this difference is key to controlling layout. One type flows naturally with text, while the other creates distinct blocks.</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Block-Level Elements</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Start on a new line</strong> and take up the full width available.</li>
                                <li>They stack on top of each other.</li>
                                <li>Examples: <code>&lt;div&gt;</code>, <code>&lt;p&gt;</code>, <code>&lt;h1&gt;</code>-<code>&lt;h6&gt;</code>, <code>&lt;section&gt;</code>, <code>&lt;header&gt;</code>, <code>&lt;footer&gt;</code>, <code>&lt;ul&gt;</code>, <code>&lt;li&gt;</code>.</li>
                            </ul>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Inline Elements</h4>
                             <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Do not start on a new line</strong>; they flow within the text.</li>
                                <li>They only take up as much width as their content needs.</li>
                                <li>Examples: <code>&lt;span&gt;</code>, <code>&lt;a&gt;</code>, <code>&lt;strong&gt;</code>, <code>&lt;em&gt;</code>, <code>&lt;img&gt;</code>.</li>
                            </ul>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. Practical Examples</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Block-level in action:</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;p&gt;This is a paragraph block.&lt;/p&gt;
&lt;div&gt;This is a div block.&lt;/div&gt;
&lt;p&gt;Another paragraph block.&lt;/p&gt;</code></pre>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Each element above will appear on its own line.</p>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Inline in action:</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;p&gt;This is &lt;strong&gt;strong text&lt;/strong&gt; and &lt;a href="#"&gt;a link&lt;/a&gt; inside one line.&lt;/p&gt;</code></pre>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">The <code>&lt;strong&gt;</code> and <code>&lt;a&gt;</code> tags flow within the paragraph without creating new lines.</p>

                             <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                             
                            <h3 class="text-xl font-semibold mb-4">III. Changing Behavior with CSS</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">You can change the default behavior of any element using the CSS <code>display</code> property. A common technique is <code>display: inline-block;</code>, which allows an element to flow inline but still accept width, height, and vertical margin/padding like a block element.</p>
                        `,
                        videos: [
                           { src: 'https://www.youtube.com/watch?v=EJr8J9Fj5fg', localPath: '', poster: 'https://i3.ytimg.com/vi/EJr8J9Fj5fg/maxresdefault.jpg', caption: 'HTML Inline vs Block Elements by The Net Ninja' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which element starts on a new line by default?", options: ["<span>", "<p>", "<a>"], answer: "<p>" },
                            { question: "Is the <a> tag normally inline or block?", options: ["Block", "Inline", "Neither"], answer: "Inline" },
                            { question: "Which CSS property can change an inline element to a block element?", options: ["float", "display", "position"], answer: "display" },
                            { question: "Which display value combines inline flow with block-level properties like width and height?", options: ["block", "inline-block", "flex"], answer: "inline-block" },
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Create a paragraph. Inside it, make one word bold with <strong> and another word a link with <a> to observe inline behavior.' },
                            { difficulty: 'intermediate', task: 'Create a navigation menu using an unordered list (<ul>). Use inline CSS (`style="display: inline-block;"`) on the list items (<li>) to make them appear side-by-side horizontally.' }
                        ]
                    },
                    {
                        id: "lesson-5-multimedia",
                        title: "Multimedia in HTML5 - Audio & Video",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🎬 Multimedia in HTML5 - Audio & Video</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~15 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">HTML5 gives you native audio and video support that works across modern browsers without needing Flash or other plugins. This makes embedding multimedia content seamless and accessible.</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. The <code>&lt;audio&gt;</code> Element</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">To embed sound, use the <code>&lt;audio&gt;</code> tag. The <code>controls</code> attribute adds the browser's default play/pause and volume UI.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;audio controls&gt;
  &lt;source src="assets/media/sample-audio.mp3" type="audio/mpeg"&gt;
  &lt;source src="assets/media/sample-audio.ogg" type="audio/ogg"&gt;
  Your browser does not support the audio element.
&lt;/audio&gt;</code></pre>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Providing multiple <code>&lt;source&gt;</code> files ensures cross-browser compatibility, as not all browsers support the same audio formats.</p>

                             <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. The <code>&lt;video&gt;</code> Element</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Embedding video is similar, using the <code>&lt;video&gt;</code> tag. You can specify <code>width</code>, <code>height</code>, and a <code>poster</code> image that displays before the video starts playing.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;video width="640" height="360" controls poster="assets/media/video-poster.jpg"&gt;
  &lt;source src="assets/media/sample-video.mp4" type="video/mp4"&gt;
  &lt;source src="assets/media/sample-video.webm" type="video/webm"&gt;
  Your browser does not support the video tag.
&lt;/video&gt;</code></pre>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Adding Subtitles with <code>&lt;track&gt;</code></h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">For accessibility, you can add subtitles or captions using the <code>&lt;track&gt;</code> element. The <code>src</code> attribute points to a WebVTT file (<code>.vtt</code>).</p>
                             <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;video controls&gt;
  &lt;source src="video.mp4" type="video/mp4"&gt;
  &lt;track src="captions_en.vtt" kind="subtitles" srclang="en" label="English" default&gt;
&lt;/video&gt;</code></pre>
                        `,
                        videos: [
                           { src: 'https://www.youtube.com/watch?v=FY9J0R2-rLk', localPath: '', poster: 'https://i3.ytimg.com/vi/FY9J0R2-rLk/maxresdefault.jpg', caption: 'HTML5 Audio & Video Tutorial by Traversy Media' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which tag is used to embed a sound file?", options: ["<sound>", "<audio>", "<music>"], answer: "<audio>" },
                            // FIX: Corrected answer for the video tag question.
                            { question: "Which tag is used to embed a video file?", options: ["<video>", "<movie>", "<media>"], answer: "<video>" },
                            { question: "What attribute adds the play/pause UI to media elements?", options: ["autoplay", "controls", "loop"], answer: "controls" },
                            { question: "How do you provide captions or subtitles for a video?", options: ["<caption>", "<track>", "<subtitle>"], answer: "<track>" },
                            { question: "Why should you include multiple <source> elements?", options: ["For styling purposes", "For cross-browser compatibility", "To make the video load faster"], answer: "For cross-browser compatibility" },
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Embed an audio file on a webpage with visible controls.' },
                            { difficulty: 'intermediate', task: 'Embed a video file with controls, a poster image, and at least two different source formats (e.g., MP4 and WebM).' },
                            { difficulty: 'hard', task: 'Create a small media gallery page with one audio element and one video element. The video must include English subtitles using the <track> tag.' }
                        ]
                    },
                    {
                        id: "lesson-6-iframes",
                        title: "Embedding External Content - <iframe> & Widgets",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🌐 Embedding External Content - &lt;iframe&gt; & Widgets</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~12 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Want to show a Google Map or a YouTube video directly on your site? The <code>&lt;iframe&gt;</code> element makes this possible by embedding another HTML document within the current one.</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. Embedding a YouTube Video</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">YouTube provides a ready-to-use embed code. The key attributes are <code>src</code>, <code>width</code>, <code>height</code>, and <code>allowfullscreen</code>.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;iframe 
  width="560" 
  height="315" 
  src="https://www.youtube.com/embed/dQw4w9WgXcQ" 
  title="YouTube video player" 
  frameborder="0" 
  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
  allowfullscreen&gt;
&lt;/iframe&gt;</code></pre>

                            <h3 class="text-xl font-semibold mb-4 mt-6">III. Embedding Google Maps</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Similarly, Google Maps offers an embed option. Note the <code>loading="lazy"</code> attribute, which improves performance by deferring the map's loading until it's about to enter the viewport.</p>
                             <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;iframe 
  src="https://www.google.com/maps/embed?pb=..." 
  width="600" 
  height="450" 
  style="border:0;" 
  allowfullscreen="" 
  loading="lazy"&gt;
&lt;/iframe&gt;</code></pre>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">IV. Security and Best Practices</h3>
                            <p class="mb-2 text-slate-600 dark:text-slate-300">Iframing untrusted content can be a security risk. The <code>sandbox</code> attribute can restrict the embedded content's capabilities.</p>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Responsive iFrames:</strong> For responsive design, wrap the iframe in a container and use CSS to maintain its aspect ratio.</li>
                                <li><strong>Accessibility:</strong> Always include a <code>title</code> attribute to describe the iframe's content to screen readers.</li>
                            </ul>
                        `,
                        videos: [
                           { src: 'https://www.youtube.com/watch?v=Uo1D6VZP4sQ', localPath: '', poster: 'https://i3.ytimg.com/vi/Uo1D6VZP4sQ/maxresdefault.jpg', caption: 'HTML <iframe> Tutorial by Traversy Media' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which tag is used to embed external web content?", options: ["<embed>", "<iframe>", "<object>"], answer: "<iframe>" },
                            { question: "What is a common CSS trick to make an iframe responsive?", options: ["Setting a fixed width and height", "Using a container with percentage-based padding-bottom", "There is no way to make it responsive"], answer: "Using a container with percentage-based padding-bottom" },
                            { question: "What does the `loading=\"lazy\"` attribute do?", options: ["Autoplays the content", "Defers loading the iframe until it is nearly visible", "Loops the content"], answer: "Defers loading the iframe until it is nearly visible" },
                            { question: "Which attribute is essential for video iframes to allow fullscreen mode?", options: ["allowfullscreen", "allow", "fullscreen"], answer: "allowfullscreen" },
                            // FIX: Corrected answer for iframe security question.
                            { question: "How can you improve the security of an iframe?", options: ["Using the sandbox attribute", "Setting width and height", "Removing the frameborder"], answer: "Using the sandbox attribute" },
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Embed your favorite YouTube video on a page.' },
                            { difficulty: 'intermediate', task: 'Embed a Google Map of your city. Make sure it is responsive by wrapping it in a div and applying the aspect-ratio CSS trick.' },
                            { difficulty: 'hard', task: 'Create a "Contact Us" page that includes a responsive Google Map of a business location and an embedded YouTube video tour of the office.' }
                        ]
                    },
                     {
                        id: "lesson-7-html5-forms",
                        title: "HTML5 Forms and Input Elements",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📝 HTML5 Forms and Input Elements</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~15 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">HTML5 supercharged forms by introducing new input types and validation attributes, making it easier to create user-friendly, accessible, and robust forms without relying on JavaScript for basic checks.</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. New Input Types</h3>
                             <p class="mb-4 text-slate-600 dark:text-slate-300">HTML5 introduced a variety of input types that provide better user interfaces (like date pickers or color pickers) and improved semantics.</p>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><code>type="email"</code>: Validates that the input is a valid email format.</li>
                                <li><code>type="number"</code>: Provides a spinner UI for number input.</li>
                                <li><code>type="date"</code>: Provides a date picker UI.</li>
                                <li><code>type="range"</code>: Creates a slider control.</li>
                                <li><code>type="color"</code>: Provides a color picker UI.</li>
                                <li><code>type="tel"</code>, <code>type="url"</code>: Optimized keyboards on mobile devices.</li>
                            </ul>

                             <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. Validation Attributes</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">You can now perform client-side validation directly in your HTML.</p>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><code>required</code>: The field must be filled out.</li>
                                <li><code>pattern</code>: The input must match a specified regular expression.</li>
                                <li><code>min</code> and <code>max</code>: Specify the minimum and maximum values for number or date inputs.</li>
                                <li><code>maxlength</code>: Limits the number of characters in a text field.</li>
                            </ul>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Example Form</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;form action="/submit" method="post"&gt;
  &lt;fieldset&gt;
    &lt;legend&gt;Contact Information&lt;/legend&gt;
    
    &lt;label for="email"&gt;Email:&lt;/label&gt;
    &lt;input type="email" id="email" name="email" required&gt;

    &lt;label for="phone"&gt;Phone (10 digits):&lt;/label&gt;
    &lt;input type="tel" id="phone" name="phone" pattern="[0-9]{10}" required&gt;
  &lt;/fieldset&gt;
  
  &lt;button type="submit"&gt;Send&lt;/button&gt;
&lt;/form&gt;</code></pre>
                             <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "Using <code>&lt;fieldset&gt;</code> and <code>&lt;legend&gt;</code> isn't just for looks; it groups related controls, which is great for accessibility. Screen readers use them to provide context to users."</p>
                            </div>
                        `,
                        videos: [
                           { src: 'https://www.youtube.com/watch?v=fNcJuPIZ2WE', localPath: '', poster: 'https://i3.ytimg.com/vi/fNcJuPIZ2WE/maxresdefault.jpg', caption: 'HTML5 Forms Tutorial by Traversy Media' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which tag is used to wrap a group of related form controls?", options: ["<form>", "<fieldset>", "<input>"], answer: "<fieldset>" },
                            { question: "How do you make a text input field mandatory?", options: ["Using the `validate` attribute", "Using the `required` attribute", "Using JavaScript"], answer: "Using the `required` attribute" },
                            { question: "What input type provides a slider UI?", options: ["number", "range", "slider"], answer: "range" },
                            { question: "Which attribute allows you to validate an input against a regular expression?", options: ["regex", "validate", "pattern"], answer: "pattern" },
                            { question: "What is the primary benefit of using `type=\"email\"` over `type=\"text\"` for an email field?", options: ["It styles the input differently", "It provides browser-level email format validation", "It automatically submits the form"], answer: "It provides browser-level email format validation" },
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Create a simple form with an email field and a submit button. Make the email field required.' },
                            { difficulty: 'intermediate', task: 'Build a booking form with a date picker (`type="date"`) and a number input (`type="number"`) for guests. Set a `min` value of 1 for the number of guests.' },
                            { difficulty: 'hard', task: 'Create a password creation form with two fields: "Password" and "Confirm Password". Use the `pattern` attribute to enforce a rule (e.g., must contain at least 8 characters, one number, one uppercase letter). Note: Validating that the two fields match requires JavaScript, but you can set up the pattern validation with just HTML.' }
                        ]
                    },
                    {
                        id: 'bonus-lesson-2-multimedia',
                        title: 'Bonus: HTML Multimedia & Embedding',
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🎬 Bonus: HTML Multimedia & Embedding</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~20 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Websites without multimedia feel flat. Adding audio, video, and embedded content brings your pages to life. But doing it wrong can break layouts or frustrate users. Today, we'll learn how to embed multimedia like a pro—responsive, accessible, and semantic.</p>
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop" alt="Flow of multimedia embedding." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">Embedding video, audio, and external content with responsive containers.</figcaption>
                            </figure>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. Core Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">HTML5 &lt;audio&gt; Element</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Embed audio directly in pages with attributes like <code>controls</code>, <code>autoplay</code>, <code>loop</code>, and <code>muted</code>. Supported formats include MP3, Ogg, and WAV.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;audio controls&gt;
  &lt;source src="audio/song.mp3" type="audio/mpeg"&gt;
  Your browser does not support the audio element.
&lt;/audio&gt;</code></pre>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">HTML5 &lt;video&gt; Element</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Embed video with multiple sources for browser compatibility. Use attributes like <code>controls</code>, <code>autoplay</code>, <code>loop</code>, <code>muted</code>, and <code>poster</code>.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;video controls width="600" poster="images/poster.jpg"&gt;
  &lt;source src="videos/sample.mp4" type="video/mp4"&gt;
  &lt;source src="videos/sample.ogg" type="video/ogg"&gt;
  Your browser does not support the video tag.
&lt;/video&gt;</code></pre>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Responsive Multimedia</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Use CSS to make your video containers responsive and maintain their aspect ratio.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-css">.video-container {
  position: relative;
  padding-bottom: 56.25%; /* 16:9 ratio */
  height: 0;
}
.video-container iframe,
.video-container video {
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
}</code></pre>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Embedding External Content with &lt;iframe&gt;</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Common uses include YouTube, Google Maps, and PDFs. Always include a <code>title</code> for accessibility.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;iframe src="https://www.google.com/maps/embed?pb=!1m18..." width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" title="Office Location"&gt;&lt;/iframe&gt;</code></pre>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=H4PZP8pLJLU', localPath: '', poster: 'https://i3.ytimg.com/vi/H4PZP8pLJLU/maxresdefault.jpg', caption: 'Responsive HTML5 Multimedia' },
                            { src: 'https://www.youtube.com/watch?v=FZ3KQo94l5g', localPath: '', poster: 'https://i3.ytimg.com/vi/FZ3KQo94l5g/maxresdefault.jpg', caption: 'Embedding Multimedia in HTML' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which attribute is used for autoplaying a video?", options: ["auto", "autoplay", "play"], answer: "autoplay" },
                            { question: "Which tag is for embedding audio?", options: ["<sound>", "<audio>", "<music>"], answer: "<audio>" },
                            { question: "What is a common CSS aspect ratio for responsive video containers?", options: ["4:3", "16:9", "1:1"], answer: "16:9" },
                            { question: "How do you embed an external YouTube video?", options: ["<iframe>", "<embed>", "<video>"], answer: "<iframe>" },
                            { question: "Which tag is used for tracking subtitles?", options: ["<sub>", "<track>", "<caption>"], answer: "<track>" }
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Embed a single MP3 audio file with controls and fallback text.' },
                            { difficulty: 'intermediate', task: 'Add a responsive video with multiple sources (MP4, OGG) and a poster image.' },
                            { difficulty: 'hard', task: 'Embed a YouTube video, an audio file, and a responsive image gallery with captions and ARIA roles.' }
                        ]
                    },
                    {
                        id: 'bonus-lesson-3-tables',
                        title: 'Bonus: HTML Tables for Data',
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📊 Bonus: HTML Tables for Data Representation</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~15 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Tables aren't just for spreadsheets—they help users understand structured information quickly. But messy tables confuse users and break responsive layouts. Today, we'll learn to create clean, accessible, and semantic HTML tables.</p>
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop" alt="Diagram of a data table." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">Table anatomy: caption, header, body, and footer for structured data.</figcaption>
                            </figure>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. Core Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Basic Table Structure</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">A semantic table is structured with <code>&lt;thead&gt;</code>, <code>&lt;tbody&gt;</code>, and optionally <code>&lt;tfoot&gt;</code>. This improves accessibility, SEO, and provides logical hooks for styling.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;table&gt;
  &lt;caption&gt;Monthly Sales Report&lt;/caption&gt;
  &lt;thead&gt;
    &lt;tr&gt;
      &lt;th scope="col"&gt;Month&lt;/th&gt;
      &lt;th scope="col"&gt;Sales&lt;/th&gt;
    &lt;/tr&gt;
  &lt;/thead&gt;
  &lt;tbody&gt;
    &lt;tr&gt;
      &lt;th scope="row"&gt;January&lt;/th&gt;
      &lt;td&gt;$1,000&lt;/td&gt;
    &lt;/tr&gt;
  &lt;/tbody&gt;
&lt;/table&gt;</code></pre>

                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Accessibility Considerations</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">The <code>scope</code> attribute (<code>"col"</code> or <code>"row"</code>) tells screen readers what a header cell refers to. The <code>&lt;caption&gt;</code> tag provides a title for the entire table. <strong>Never use tables for layout purposes.</strong></p>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=tr8rgPxjEos', localPath: '', poster: 'https://i3.ytimg.com/vi/tr8rgPxjEos/maxresdefault.jpg', caption: 'HTML Tables for Beginners by FreeCodeCamp.' },
                            { src: 'https://www.youtube.com/watch?v=Q2__cM130D0', localPath: '', poster: 'https://i3.ytimg.com/vi/Q2__cM130D0/maxresdefault.jpg', caption: 'Creating Responsive Tables with Kevin Powell.' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which tag defines the table header section?", options: ["<head>", "<th>", "<thead>"], answer: "<thead>" },
                            { question: "Which tag groups the main body content of a table?", options: ["<tbody>", "<tr>", "<td>"], answer: "<tbody>" },
                            { question: "What does the `scope` attribute on a <th> do?", options: ["Defines a role for JavaScript", "Improves accessibility for screen readers", "Sets the visual scope"], answer: "Improves accessibility for screen readers" },
                            { question: "What is the semantic tag for a table's title?", options: ["<title>", "<caption>", "<label>"], answer: "<caption>" },
                            { question: "How do you merge cells horizontally?", options: ["colspan", "rowspan", "merge"], answer: "colspan" }
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Create a simple table with 3 columns and 4 rows, including a caption.' },
                            { difficulty: 'intermediate', task: 'Add <thead> and <tbody> sections to your table and include correct `scope` attributes on your header cells.' },
                            { difficulty: 'hard', task: 'Make the table responsive using CSS media queries so that it stacks vertically on small screens.' }
                        ]
                    },
                    {
                        id: 'bonus-lesson-4-seo',
                        title: 'Bonus: Semantic HTML & SEO',
                        content: `
                            <h2 class="text-2xl font-bold mb-2">📈 Bonus: Semantic HTML & SEO</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~20 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Your website might look great, but search engines and assistive technologies don't see it the same way users do. Semantic HTML helps them understand your content's structure and meaning, which is crucial for SEO and accessibility.</p>
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1559526324-c1f275fbfa32?q=80&w=2070&auto=format&fit=crop" alt="Diagram showing SEO concepts." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">Semantic elements create structured content for search engines and screen readers.</figcaption>
                            </figure>

                             <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. Core Concepts</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Semantic HTML uses tags that convey the meaning of the content within them. Instead of generic <code>&lt;div&gt;</code> and <code>&lt;span&gt;</code> tags, you use descriptive tags.</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Key Semantic Elements & SEO</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><code>&lt;header&gt;</code>, <code>&lt;nav&gt;</code>, <code>&lt;main&gt;</code>, <code>&lt;footer&gt;</code>: These create "landmarks" that help search engines understand the page layout.</li>
                                <li><code>&lt;article&gt;</code> vs. <code>&lt;section&gt;</code>: An <code>&lt;article&gt;</code> should be a self-contained piece of content (like a blog post). A <code>&lt;section&gt;</code> is a thematic grouping of content.</li>
                                <li><code>&lt;h1&gt;</code>-<code>&lt;h6&gt;</code>: Heading tags create a topic hierarchy. Use only one <code>&lt;h1&gt;</code> per page for the main title.</li>
                            </ul>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=b21p4G10C4M', localPath: '', poster: 'https://i3.ytimg.com/vi/b21p4G10C4M/maxresdefault.jpg', caption: 'Semantic HTML For Better SEO by Traversy Media' },
                            { src: 'https://www.youtube.com/watch?v=sBzRwzY7G-k', localPath: '', poster: 'https://i3.ytimg.com/vi/sBzRwzY7G-k/maxresdefault.jpg', caption: 'Semantic HTML & SEO Best Practices' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which tag represents the main, unique content of a page?", options: ["<div>", "<main>", "<section>"], answer: "<main>" },
                            { question: "Which tag is best for self-contained content like a blog post?", options: ["<article>", "<section>", "<aside>"], answer: "<article>" },
                            { question: "Which tag is used for complementary content like a sidebar?", options: ["<aside>", "<nav>", "<footer>"], answer: "<aside>" },
                            { question: "Which tag is used to provide an SEO meta description?", options: ["<meta>", "<link>", "<script>"], answer: "<meta>" },
                            { question: "What is the best practice for heading hierarchy for SEO?", options: ["Using multiple <h1> tags", "Using one <h1>, with <h2> nested logically", "Not using headings"], answer: "Using one <h1>, with <h2> nested logically" }
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Wrap the main sections of a page in <section> and <article> tags.' },
                            { difficulty: 'intermediate', task: 'Implement a full page layout with <header>, <nav>, <main>, and <footer>, including proper headings.' },
                            { difficulty: 'hard', task: 'Add SEO meta tags and structure multiple articles with <section> and <aside> for related content.' }
                        ]
                    },
                    {
                        id: 'bonus-lesson-5-aria',
                        title: 'Bonus: Accessibility & ARIA Roles',
                        content: `
                             <h2 class="text-2xl font-bold mb-2">♿ Bonus: Accessibility & ARIA Roles</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Intermediate | Duration: ~20 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">A website isn't just for people who can see or hear. Accessibility ensures everyone can navigate, understand, and interact with your content. Today, we'll explore ARIA roles and semantic HTML to make your pages universally usable.</p>
                            <figure class="my-6">
                                <img src="https://images.unsplash.com/photo-1573496774431-42c052a422a5?q=80&w=2070&auto=format&fit=crop" alt="Diverse group of people using technology." class="rounded-lg shadow-md border border-slate-200 dark:border-slate-700">
                                <figcaption class="text-center text-sm text-slate-500 mt-2">Semantic HTML and ARIA roles help users with assistive tech navigate content efficiently.</figcaption>
                            </figure>

                             <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. Core Concepts</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Semantic HTML for Accessibility</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">Using tags like <code>&lt;nav&gt;</code>, <code>&lt;main&gt;</code>, and <code>&lt;button&gt;</code> provides a baseline of accessibility, as screen readers understand what these landmarks are for.</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Introduction to ARIA</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">ARIA (Accessible Rich Internet Applications) adds extra accessibility information when semantic HTML isn't enough. It uses roles, states, and properties.</p>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><strong>Roles</strong> describe the type of element (e.g., <code>role="button"</code>).</li>
                                <li><strong>States & Properties</strong> describe the element's status (e.g., <code>aria-expanded="true"</code>).</li>
                            </ul>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;!-- Use when a &lt;div&gt; must act like a button --&gt;
&lt;div role="button" aria-pressed="false"&gt;Toggle Menu&lt;/div&gt;

&lt;!-- A live alert for dynamic content --&gt;
&lt;div role="alert"&gt;Form submitted successfully!&lt;/div&gt;</code></pre>

                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "First rule of ARIA: Don't use ARIA if you can use a semantic HTML element instead. For example, always prefer <code>&lt;button&gt;</code> over <code>&lt;div role='button'&gt;</code>."</p>
                            </div>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=3Xc3CA655Y4', localPath: '', poster: 'https://i3.ytimg.com/vi/3Xc3CA655Y4/maxresdefault.jpg', caption: 'Web Accessibility Tutorial - ARIA Roles' },
                            { src: 'https://www.youtube.com/watch?v=Hc5ZUyA4zNs', localPath: '', poster: 'https://i3.ytimg.com/vi/Hc5ZUyA4zNs/maxresdefault.jpg', caption: 'ARIA Roles & Accessibility Best Practices' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which semantic tag creates a landmark for the main content?", options: ["<div>", "<main>", "<section>"], answer: "<main>" },
                            { question: "What ARIA role should you add to a <div> to make it behave like a button?", options: [`role="button"`, `role="link"`, `role="menu"`], answer: `role="button"` },
                            { question: "Which role is used to announce live message alerts to screen readers?", options: ["<div>", `role="alert"`, "<span>"], answer: `role="alert"` },
                            { question: "Which ARIA attribute is crucial for making a modal dialog accessible?", options: [`aria-modal="true"`, `aria-hidden="false"`, `aria-live="off"`], answer: `aria-modal="true"` },
                            { question: "What is the most accessible way to label a form input?", options: ["Using a placeholder", "Using a <label> tag", "Using an aria-hidden attribute"], answer: "<label>" }
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Add semantic <header>, <main>, and <footer> landmarks to a page.' },
                            { difficulty: 'intermediate', task: 'Assign ARIA roles to non-semantic elements, like a <div> used as a button or a custom navigation bar.' },
                            { difficulty: 'hard', task: 'Build an accessible modal dialog with `role="dialog"`, proper ARIA attributes, and test it with a keyboard and screen reader.' }
                        ]
                    }
                ]
            }
        ]
    },
    {
        id: "advanced-html-integration",
        title: "Advanced HTML and Integration",
        description: "Dive deeper into HTML with advanced forms, graphics using SVG and Canvas, and other powerful integration techniques for professional web development.",
        imageUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=2070&auto=format&fit=crop",
        level: "Advanced",
        modules: [
            {
                id: "module-1-advanced-techniques",
                title: "Advanced Techniques",
                chapters: [
                    {
                        id: "lesson-1-entities-symbols",
                        title: "HTML Entities and Symbols",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">✍️ HTML Entities and Symbols</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Advanced | Duration: ~10 minutes)</p>
                            
                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Lesson Introduction</h3>
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">🎯 Opening Hook</h4>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">"Ever tried to display <code>&lt;</code> or <code>&gt;</code> on a webpage and it vanished? That's because HTML interprets them as code. HTML entities are the solution—they're like secret codes that tell the browser 'show this character, don't run it'."</p>
                            
                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>
                            
                            <h3 class="text-xl font-semibold mb-4">II. What Are HTML Entities?</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">HTML entities are special codes that represent reserved characters or symbols. They follow the syntax <code>&amp;name;</code> or <code>&amp;#code;</code>.</p>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Common Entities</h4>
                            <ul class="list-disc list-inside space-y-2 mb-4 pl-4 text-slate-600 dark:text-slate-300">
                                <li><code>&amp;lt;</code> for <code>&lt;</code> (less than)</li>
                                <li><code>&amp;gt;</code> for <code>&gt;</code> (greater than)</li>
                                <li><code>&amp;amp;</code> for <code>&amp;</code> (ampersand)</li>
                                <li><code>&amp;copy;</code> for © (copyright)</li>
                                <li><code>&amp;euro;</code> for € (euro)</li>
                                <li><code>&amp;#x1F600;</code> for 😀 (emoji)</li>
                            </ul>
                            
                            <h4 class="text-lg font-semibold text-slate-800 dark:text-slate-200 mb-2 mt-4">Example Usage</h4>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;p&gt;Use &amp;lt;div&amp;gt; to create a division.&lt;/p&gt;
&lt;p&gt;Copyright &amp;copy; 2025. All rights reserved.&lt;/p&gt;
&lt;p&gt;This is a smiley face: &amp;#x1F600;&lt;/p&gt;
</code></pre>
                            <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "Using entities is crucial for displaying code snippets or special characters reliably. It prevents the browser from misinterpreting your content as broken HTML."</p>
                            </div>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=Yzv-NI2lWmE', localPath: '', poster: 'https://i3.ytimg.com/vi/Yzv-NI2lWmE/maxresdefault.jpg', caption: 'HTML Entities Explained by Traversy Media' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "How do you correctly display the `<` character in HTML?", options: ["<", "&lt;", "&gt;"], answer: "&lt;" },
                            // FIX: Added missing 'answer' property to the QuizQuestion object to satisfy the type.
                            { question: "How do you show the © copyright symbol?", options: ["&copy;", "&reg;", "&tm;"], answer: "&copy;" }
                        ]}],
                        codeChallenges: [{ difficulty: 'easy', task: 'Create a page with the copyright symbol (©) and the less-than symbol (<) using entities.' }]
                    },
                    {
                        id: "lesson-2-svg-and-canvas",
                        title: "SVG and Canvas",
                        content: `
                            <h2 class="text-2xl font-bold mb-2">🎨 SVG and Canvas</h2>
                            <p class="text-sm text-slate-500 dark:text-slate-400 mb-6">(Advanced | Duration: ~15 minutes)</p>

                            <h3 class="text-xl font-semibold mb-4 mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">I. Introduction</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">HTML provides two powerful ways to create graphics on the web: SVG (Scalable Vector Graphics) and the <code>&lt;canvas&gt;</code> element. They serve different purposes but both allow for rich, dynamic visuals.</p>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">II. SVG: For Vector Graphics</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">SVG is an XML-based language for describing 2D graphics. Since it's vector-based, it scales perfectly to any size without losing quality. It's great for logos, icons, and illustrations.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;svg width="100" height="100"&gt;
  &lt;circle cx="50" cy="50" r="40" stroke="green" stroke-width="4" fill="yellow" /&gt;
&lt;/svg&gt;</code></pre>

                            <hr class="my-8 border-slate-200 dark:border-slate-700"/>

                            <h3 class="text-xl font-semibold mb-4">III. Canvas: For Pixel-Based Graphics</h3>
                            <p class="mb-4 text-slate-600 dark:text-slate-300">The <code>&lt;canvas&gt;</code> element provides a drawing surface that you can manipulate with JavaScript. It's pixel-based (raster), making it ideal for games, data visualizations, and image editing.</p>
                            <pre class="bg-slate-900 text-white p-4 rounded-lg overflow-x-auto my-4"><code class="language-html">&lt;canvas id="myCanvas" width="200" height="100" style="border:1px solid #000;"&gt;&lt;/canvas&gt;
&lt;script&gt;
  const c = document.getElementById("myCanvas");
  const ctx = c.getContext("2d");
  ctx.fillStyle = "red";
  ctx.fillRect(20, 20, 150, 75);
&lt;/script&gt;</code></pre>
                             <div class="bg-purple-50 dark:bg-slate-800/60 border-l-4 border-purple-400 p-4 my-4 rounded-r-lg">
                                <p class="text-sm text-purple-800 dark:text-purple-200">🧠 <strong>Mentor Talk:</strong> "Choose SVG for static, scalable graphics and SEO-friendliness. Choose Canvas for dynamic, high-performance animations and games where individual elements don't need to be interactive."</p>
                            </div>
                        `,
                        videos: [
                            { src: 'https://www.youtube.com/watch?v=13FWk282iV8', localPath: '', poster: 'https://i3.ytimg.com/vi/13FWk282iV8/maxresdefault.jpg', caption: 'SVG & Canvas Crash Course by Traversy Media' }
                        ],
                        interactiveComponents: [{ type: 'quiz', questions: [
                            { question: "Which graphics technology is vector-based and scalable?", options: ["Canvas", "SVG", "JPEG"], answer: "SVG" },
                            { question: "Which technology is better suited for high-performance games?", options: ["Canvas", "SVG", "PNG"], answer: "Canvas" },
                            { question: "How do you draw on a <canvas> element?", options: ["With CSS", "With HTML attributes", "With JavaScript"], answer: "With JavaScript" },
                        ]}],
                        codeChallenges: [
                            { difficulty: 'easy', task: 'Create a simple SVG graphic with a rectangle and a circle inside it.' },
                            { difficulty: 'intermediate', task: 'Use the <canvas> element and JavaScript to draw a simple smiley face.' },
                            { difficulty: 'hard', task: 'Create an interactive <canvas> element where clicking on it draws a small, randomly colored circle at the cursor\'s position.' }
                        ]
                    }
                ]
            }
        ]
    }
];
