export interface User {
  name: string;
  avatar: string;
  title: string;
  status: string;
  points: number;
  dailyStreak: number;
  longestStreak: number;
  challengesCompleted: number;
  achievements: number;
  certificateProgress: number;
  hoursLearned: number;
  completedCourses: number;
  goal: string;
  email: string;
}

export interface Badge {
  name: string;
  description: string;
  image: string;
}

export interface CodeChallenge {
  difficulty: 'easy' | 'intermediate' | 'hard';
  task: string;
  // Fix: Add optional `editorConfig` property to support editor settings in challenges.
  editorConfig?: {
    autoTagRecommendation: boolean;
    autoCloseTags: boolean;
    syntaxHighlighting: boolean;
    livePreview: boolean;
    errorDetection: boolean;
  };
}

// Fix: Add `QuizQuestion` interface for structured quiz questions.
export interface QuizQuestion {
  question: string;
  options: string[];
  answer: string;
}

export interface InteractiveComponent {
  type: 'drag-and-drop' | 'quiz' | 'multiple-choice';
  description?: string;
  // Fix: Allow `questions` to be an array of strings or `QuizQuestion` objects.
  questions?: (string | QuizQuestion)[];
}

// Fix: Add Video and Image interfaces to support multimedia content in chapters.
export interface Video {
  src: string;
  localPath: string;
  poster: string;
  caption: string;
}

export interface Image {
  src: string;
  alt: string;
}

export interface Chapter {
  id: string;
  title: string;
  content: string;
  interactiveComponents: InteractiveComponent[];
  // Fix: Corrected typo from CodeCodeChallenge to CodeChallenge.
  codeChallenges: CodeChallenge[];
  // Fix: Add optional `videos` and `images` properties to support multimedia content.
  videos?: Video[];
  images?: Image[];
}

export interface Module {
  id: string;
  title:string;
  chapters: Chapter[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  level: string;
  modules: Module[];
}

export type ReferenceItem =
  | {
      type: 'image';
      url: string;
      description: string;
    }
  | {
      type: 'component';
      componentId: string;
      description: string;
    };

export interface LabChallenge {
  id: string;
  level: 'easy' | 'intermediate' | 'hard';
  title: string;
  description: string;
  requirements?: string[];
  constraints?: string[];
  hint?: string;
  initialCode: {
    html: string;
    css?: string;
  };
  referenceItems?: ReferenceItem[];
  uiConfig?: {
    [key: string]: any;
  };
  editorConfig?: {
    autoTagRecommendation?: boolean;
    autoCloseTags?: boolean;
    syntaxErrorDetection?: boolean;
  };
}

export interface Bookmark {
  courseId: string;
  moduleId: string;
  chapterId: string;
  title: string;
  context: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
  path?: string;
}