import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { Notification } from '../types';

interface NotificationContextType {
  notifications: Notification[];
  addNotification: (title: string, message: string, path?: string) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
  reminderTime: string;
  setReminderTime: (time: string) => void;
  scheduleReminder: (time: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

let reminderTimeout: number | undefined;

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>(() => {
    try {
      const stored = localStorage.getItem('notifications');
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  });

  const [reminderTime, setReminderTime] = useState<string>(() => localStorage.getItem('reminderTime') || '');

  useEffect(() => {
    localStorage.setItem('notifications', JSON.stringify(notifications));
  }, [notifications]);
  
  useEffect(() => {
    localStorage.setItem('reminderTime', reminderTime);
  }, [reminderTime]);

  const addNotification = useCallback((title: string, message: string, path?: string) => {
    const newNotification: Notification = {
      id: `${Date.now()}-${Math.random()}`,
      title,
      message,
      timestamp: Date.now(),
      read: false,
      path,
    };
    setNotifications(prev => [newNotification, ...prev]);
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const showReminderNotification = useCallback(() => {
    if (Notification.permission === 'granted') {
      new Notification('Nova Learning Reminder', {
        body: "Time to continue your learning journey! Consistency is key.",
        icon: "https://www.gstatic.com/images/branding/product/1x/google_cloud_192dp.png",
      });
      addNotification("Daily Reminder", "Time to continue your learning journey!");
    }
  }, [addNotification]);
  
  const scheduleReminder = useCallback((time: string) => {
    if (reminderTimeout) {
      clearTimeout(reminderTimeout);
    }

    if (!time || Notification.permission !== 'granted') {
      return;
    }

    const [hours, minutes] = time.split(':').map(Number);
    const now = new Date();
    const reminderDate = new Date();
    reminderDate.setHours(hours, minutes, 0, 0);

    if (reminderDate <= now) {
        reminderDate.setDate(reminderDate.getDate() + 1);
    }
    
    const timeUntilReminder = reminderDate.getTime() - now.getTime();
    
    console.log(`Reminder scheduled in ${timeUntilReminder / 1000 / 60} minutes.`);

    reminderTimeout = window.setTimeout(() => {
        showReminderNotification();
        scheduleReminder(time); 
    }, timeUntilReminder);

  }, [showReminderNotification]);
  
  useEffect(() => {
    const isOnboardingComplete = localStorage.getItem('onboardingComplete') === 'true';
    const hasSeenWelcome = localStorage.getItem('hasSeenWelcome') === 'true';

    if (isOnboardingComplete && !hasSeenWelcome) {
      addNotification("Welcome to Nova!", "We're excited to have you. Start by exploring a course.", "/courses");
      localStorage.setItem('hasSeenWelcome', 'true');
    }
    
    if(reminderTime) {
        scheduleReminder(reminderTime);
    }
  }, [addNotification, scheduleReminder, reminderTime]);


  return (
    <NotificationContext.Provider value={{ notifications, addNotification, removeNotification, clearNotifications, reminderTime, setReminderTime, scheduleReminder }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};