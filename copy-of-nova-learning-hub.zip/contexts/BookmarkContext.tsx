import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { Bookmark } from '../types';
import { useToast } from './ToastContext';

interface BookmarkContextType {
  bookmarks: Bookmark[];
  addBookmark: (bookmark: Bookmark) => void;
  removeBookmark: (chapterId: string) => void;
  isBookmarked: (chapterId: string) => boolean;
}

const BookmarkContext = createContext<BookmarkContextType | undefined>(undefined);

export const BookmarkProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    try {
      const storedBookmarks = localStorage.getItem('bookmarks');
      return storedBookmarks ? JSON.parse(storedBookmarks) : [];
    } catch (error) {
      console.error("Failed to parse bookmarks from localStorage", error);
      return [];
    }
  });
  
  const { addToast } = useToast();

  useEffect(() => {
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
  }, [bookmarks]);

  const addBookmark = useCallback((bookmark: Bookmark) => {
    setBookmarks(prev => {
      // Avoid duplicates
      if (prev.some(b => b.chapterId === bookmark.chapterId)) {
        return prev;
      }
      addToast("Bookmark added!");
      return [bookmark, ...prev];
    });
  }, [addToast]);

  const removeBookmark = useCallback((chapterId: string) => {
    setBookmarks(prev => prev.filter(b => b.chapterId !== chapterId));
    addToast("Bookmark removed.");
  }, [addToast]);

  const isBookmarked = useCallback((chapterId: string) => {
    return bookmarks.some(b => b.chapterId === chapterId);
  }, [bookmarks]);

  return (
    <BookmarkContext.Provider value={{ bookmarks, addBookmark, removeBookmark, isBookmarked }}>
      {children}
    </BookmarkContext.Provider>
  );
};

export const useBookmarks = () => {
  const context = useContext(BookmarkContext);
  if (context === undefined) {
    throw new Error('useBookmarks must be used within a BookmarkProvider');
  }
  return context;
};