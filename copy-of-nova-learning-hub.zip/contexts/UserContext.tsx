import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { User } from '../types';
import { DEFAULT_USER } from '../constants';

interface UserContextType {
  user: User;
  setUser: (user: Partial<User>) => void;
  isOnboardingComplete: boolean;
  completeOnboarding: (name: string, avatar: string) => void;
  logout: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUserState] = useState<User>(() => {
    try {
      const storedUser = localStorage.getItem('userData');
      return storedUser ? JSON.parse(storedUser) : DEFAULT_USER;
    } catch (error) {
      return DEFAULT_USER;
    }
  });

  const [isOnboardingComplete, setIsOnboardingComplete] = useState<boolean>(() => {
    return typeof window !== 'undefined' && localStorage.getItem('onboardingComplete') === 'true';
  });

  const navigate = useNavigate();

  const setUser = (updatedFields: Partial<User>) => {
    const updatedUser = { ...user, ...updatedFields };
    setUserState(updatedUser);
    localStorage.setItem('userData', JSON.stringify(updatedUser));
  };

  const completeOnboarding = (name: string, avatar: string) => {
    const newUser = { ...DEFAULT_USER, name, avatar };
    setUserState(newUser);
    localStorage.setItem('userData', JSON.stringify(newUser));
    localStorage.setItem('onboardingComplete', 'true');
    setIsOnboardingComplete(true);
  };

  const logout = useCallback(() => {
    // Clear all app-related data from localStorage for a full reset
    localStorage.removeItem('userData');
    localStorage.removeItem('onboardingComplete');
    localStorage.removeItem('theme');
    localStorage.removeItem('themeColor');
    localStorage.removeItem('bookmarks');
    localStorage.removeItem('notifications');
    localStorage.removeItem('reminderTime');
    
    // Reset the application's state.
    setUserState(DEFAULT_USER);
    setIsOnboardingComplete(false);

    // Explicitly navigate to the welcome screen
    navigate('/onboarding', { replace: true });
  }, [navigate]);

  useEffect(() => {
    // This effect synchronizes logout across multiple tabs
    const syncLogout = (event: StorageEvent) => {
        if (event.key === 'onboardingComplete' && event.newValue === null) {
            console.log('Detected logout from another tab. Syncing...');
            // When another tab logs out, this tab will reset its state and
            // the ProtectedRoute component will handle the redirection.
            setUserState(DEFAULT_USER);
            setIsOnboardingComplete(false);
        }
    };

    window.addEventListener('storage', syncLogout);
    return () => {
        window.removeEventListener('storage', syncLogout);
    };
  }, []);

  useEffect(() => {
    try {
        const storedUser = localStorage.getItem('userData');
        if (storedUser) {
            setUserState(JSON.parse(storedUser));
        }
        const onboardingStatus = localStorage.getItem('onboardingComplete') === 'true';
        setIsOnboardingComplete(onboardingStatus);
    } catch (e) {
        // In case of parsing errors, fallback to default
        setUserState(DEFAULT_USER);
        setIsOnboardingComplete(false);
    }
  }, []);

  return (
    <UserContext.Provider value={{ user, setUser, isOnboardingComplete, completeOnboarding, logout }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};