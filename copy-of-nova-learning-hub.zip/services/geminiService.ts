// This file simulates a call to the Gemini API for code analysis.
// In a real application, you would use the @google/genai package here.
// IMPORTANT: Do NOT expose your API key on the client-side. This logic should
// typically live on a server that your frontend calls.

import { LabChallenge } from '../types';

// import { GoogleGenAI, Type } from "@google/genai";

export const analyzeCode = async (code: string, challenge: LabChallenge): Promise<{ correctnessPercentage: number; suggestions: string[]; }> => {
  console.log("Simulating offline Gemini analysis for challenge:", challenge.title);

  // --- START: Mock Offline Logic ---
  // This simulates the network delay of an API call.
  await new Promise(resolve => setTimeout(resolve, 1500));

  // This simulates context-aware analysis based on challenge requirements.
  let score = 0;
  const suggestions = [];
  const requirements = challenge.requirements || [];
  const totalChecks = requirements.length;
  let checksPassed = 0;
  
  if (totalChecks === 0) {
      return { correctnessPercentage: 100, suggestions: ["This challenge has no specific requirements to check against, but great job putting it together!"] };
  }
  
  const lowerCaseCode = code.toLowerCase();

  requirements.forEach(req => {
      const lowerReq = req.toLowerCase();
      let passed = false;
      
      // Heuristic checks based on keywords in requirements
      if (lowerReq.includes('h1') && lowerCaseCode.includes('<h1')) passed = true;
      else if (lowerReq.includes('paragraph') && lowerCaseCode.includes('<p')) passed = true;
      else if (lowerReq.includes('list of your hobbies') && lowerCaseCode.includes('<ul')) passed = true;
      else if (lowerReq.includes('email link') && /<a\s+[^>]*href\s*=\s*['"]mailto:/i.test(code)) passed = true;
      else if (lowerReq.includes('unordered list') && lowerCaseCode.includes('<ul')) passed = true;
      else if (lowerReq.includes('ordered list') && lowerCaseCode.includes('<ol')) passed = true;
      else if (lowerReq.includes('<time> tag') && lowerCaseCode.includes('<time')) passed = true;
      else if (lowerReq.includes('form') && lowerCaseCode.includes('<form')) passed = true;
      else if (lowerReq.includes('input') && lowerCaseCode.includes('<input')) passed = true;
      else if (lowerReq.includes('submit button') && /<button[^>]*type\s*=\s*['"]submit['"]/i.test(code)) passed = true;
      else if (lowerReq.includes('table') && lowerCaseCode.includes('<table')) passed = true;
      else if (lowerReq.includes('semantic structure') && /<(header|nav|main|section|article|footer)\b/i.test(code)) passed = true;
      else if (lowerReq.includes('no css styling allowed')) passed = true; // Cannot check CSS here, so we assume it's met.
      
      if (passed) {
          checksPassed++;
      } else {
          suggestions.push(`Your code might be missing the requirement: "${req}"`);
      }
  });

  score = totalChecks > 0 ? Math.round((checksPassed / totalChecks) * 100) : 100;

  if (suggestions.length === 0 && totalChecks > 0) {
      suggestions.push("Excellent work! You've met all the requirements for this challenge.");
      if (challenge.hint) {
        suggestions.push(`As a next step, you could try to expand on this: ${challenge.hint}`);
      }
  } else if (suggestions.length < 2) {
      suggestions.push("Keep going! You're on the right track.");
  }


  return {
    correctnessPercentage: score,
    suggestions: suggestions,
  };
  // --- END: Mock Logic ---
};