import React, { useState, useEffect, useRef } from 'react';
import { Routes, Route, Outlet, Navigate, Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import FooterNav from './components/FooterNav';
import Dashboard from './pages/Dashboard';
import Courses from './pages/Courses';
import CourseDetail from './pages/CourseDetail';
import ChapterView from './pages/ChapterView';
import Challenges from './pages/Challenges';
import Search from './pages/Search';
import Profile from './pages/Profile';
import NotFound from './pages/NotFound';
import { useUser } from './contexts/UserContext';
import Onboarding from './pages/Onboarding';
import EditProfile from './pages/EditProfile';
import Settings from './pages/Settings';
import Bookmarks from './pages/Bookmarks';
import Community from './pages/Community';
import { useNotifications } from './contexts/NotificationContext';
import { Logo, BookIcon, Bars3Icon, MagnifyingGlassIcon, BellIcon, HomeIcon, BookOpenIcon, BeakerIcon, UserCircleIcon, Cog6ToothIcon, PencilIcon, ArrowRightOnRectangleIcon, DocumentTextIcon, BookmarkIcon, UsersIcon, XMarkIcon, ArrowLeftIcon } from './components/Icons';

// --- SideMenu Component ---
interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const NavItem = ({ to, icon, label, onClick }: { to: string, icon: React.ReactNode, label: string, onClick: () => void }) => (
  <NavLink
    to={to}
    onClick={onClick}
    className={({ isActive }) =>
      `flex items-center px-4 py-3 rounded-lg transition-colors duration-200 ${
        isActive
          ? 'bg-slate-700 text-white'
          : 'text-slate-400 hover:bg-slate-700/50 hover:text-slate-200'
      }`
    }
  >
    <div className="w-6 h-6 mr-4">{icon}</div>
    <span className="font-semibold">{label}</span>
  </NavLink>
);

const SideMenu: React.FC<SideMenuProps> = ({ isOpen, onClose }) => {
  return (
    <>
      <div
        onClick={onClose}
        className={`fixed inset-0 bg-black/60 z-40 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        aria-hidden="true"
      />
      
      <div
        className={`fixed top-0 left-0 bottom-0 w-72 bg-slate-900 shadow-2xl z-50 transform transition-transform duration-300 ease-in-out flex flex-col ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        role="dialog"
        aria-modal="true"
      >
        <div>
          <div className="p-4 border-b border-slate-800 flex items-center gap-3">
            <Logo className="w-9 h-9 text-primary-500" />
            <h2 className="text-xl font-bold text-white">Nova Learning</h2>
          </div>
          <nav className="p-4 space-y-2">
            <NavItem to="/dashboard" icon={<HomeIcon />} label="Home" onClick={onClose} />
            <NavItem to="/courses" icon={<BookOpenIcon />} label="Courses" onClick={onClose} />
            <NavItem to="/challenges" icon={<BeakerIcon />} label="Labs" onClick={onClose} />
            <NavItem to="/bookmarks" icon={<BookmarkIcon solid />} label="Bookmarks" onClick={onClose} />
            <NavItem to="/community" icon={<UsersIcon />} label="Community" onClick={onClose} />
            <NavItem to="/profile" icon={<UserCircleIcon />} label="Profile" onClick={onClose} />
          </nav>
        </div>
        <footer className="mt-auto p-4 text-center text-xs text-slate-500 border-t border-slate-800">
            <p>🇪🇹 Proudly Made in Ethiopia</p>
            <p className="my-1">---------</p>
            <p>Nova Tech Labs</p>
            <p>Designed by: <a href="mailto:ambesaw05@gmail.com" className="underline hover:text-slate-300">Andualem T.</a></p>
            <p>October 2025, Addis Ababa, Ethiopia</p>
        </footer>
      </div>
    </>
  );
};

// --- Notification Panel Component ---
interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const NotificationItem: React.FC<{ notification: any, onRemove: (id: string) => void, onClosePanel: () => void }> = ({ notification, onRemove, onClosePanel }) => {
    const handleRemove = (e: React.MouseEvent) => {
        e.stopPropagation();
        e.preventDefault();
        onRemove(notification.id);
    };

    const content = (
        <div className="p-3 hover:bg-slate-700/50 rounded-lg cursor-pointer transition-colors duration-200 border-b border-slate-700/50 last:border-b-0 flex justify-between items-start gap-2">
            <div className="flex-grow">
                <p className={`text-sm ${notification.read ? 'text-slate-400' : 'text-slate-200 font-semibold'}`}>{notification.title}</p>
                <p className="text-xs text-slate-500 mt-1">{new Date(notification.timestamp).toLocaleString()}</p>
            </div>
            <button onClick={handleRemove} title="Dismiss notification" className="p-1 -m-1 text-slate-500 hover:text-white rounded-full flex-shrink-0">
                <XMarkIcon className="w-4 h-4" />
            </button>
        </div>
    );

    if (notification.path) {
        return <Link to={notification.path} onClick={onClosePanel}>{content}</Link>;
    }
    return <div onClick={(e) => e.stopPropagation()}>{content}</div>;
};

const NotificationPanel: React.FC<NotificationPanelProps> = ({ isOpen, onClose }) => {
    const { notifications, removeNotification, clearNotifications } = useNotifications();
    const panelRef = useRef<HTMLDivElement>(null);
    const unreadCount = notifications.filter(n => !n.read).length;

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
                onClose();
            }
        };
        if (isOpen) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [isOpen, onClose]);

    return (
        <div ref={panelRef} className={`absolute top-full right-0 mt-3 w-80 max-w-sm bg-slate-800/80 backdrop-blur-md rounded-xl shadow-2xl z-20 border border-slate-700 transition-all duration-300 ease-in-out ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'}`}
        >
            <div className="p-4 border-b border-slate-700 flex justify-between items-center">
                <h3 className="font-bold text-white">Notifications</h3>
                {unreadCount > 0 && <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount}</span>}
            </div>
            <div className="p-2 max-h-96 overflow-y-auto">
                {notifications.length > 0 ? (
                    notifications.map(n => <NotificationItem key={n.id} notification={n} onRemove={removeNotification} onClosePanel={onClose} />)
                ) : (
                    <p className="text-center text-sm text-slate-400 py-8">No notifications yet.</p>
                )}
            </div>
            {notifications.length > 0 && (
                <div className="p-3 border-t border-slate-700 text-center">
                    <button onClick={clearNotifications} className="text-sm text-primary-400 hover:underline">
                        Clear All
                    </button>
                </div>
            )}
        </div>
    );
};

// --- Profile Dropdown Component ---
const ProfileDropdown: React.FC<{ isOpen: boolean; onClose: () => void; user: any; onLogout: () => void; }> = ({ isOpen, onClose, user, onLogout }) => {
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                onClose();
            }
        };
        if (isOpen) {
            document.addEventListener("mousedown", handleClickOutside);
        }
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [isOpen, onClose]);

    const DropdownLink: React.FC<{ to: string, icon: React.ReactNode, label: string }> = ({ to, icon, label }) => (
        <Link to={to} onClick={onClose} className="flex items-center gap-3 w-full text-left p-2.5 rounded-lg text-slate-300 hover:bg-slate-700/50 hover:text-white transition-colors duration-200">
            <div className="w-5 h-5">{icon}</div>
            <span className="font-semibold text-sm">{label}</span>
        </Link>
    );

    return (
        <div ref={dropdownRef} className={`absolute top-full right-0 mt-3 w-64 bg-slate-800/80 backdrop-blur-md rounded-xl shadow-2xl z-20 border border-slate-700 transition-all duration-300 ease-in-out ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'}`}>
            <div className="p-4 flex flex-col items-center">
                <img src={user.avatar} alt="User avatar" className="w-16 h-16 rounded-full border-2 border-slate-600"/>
                <p className="font-bold mt-2 text-white">{user.name}</p>
            </div>
            <hr className="border-slate-700/50 mx-3"/>
            <nav className="p-2 space-y-1">
                <DropdownLink to="/profile" icon={<UserCircleIcon />} label="View Profile" />
                <DropdownLink to="/profile/edit" icon={<PencilIcon />} label="Edit Profile" />
                <DropdownLink to="/settings" icon={<BellIcon />} label="Notifications" />
                <DropdownLink to="/settings" icon={<Cog6ToothIcon />} label="Settings" />
                 <button onClick={onLogout} className="flex items-center gap-3 w-full text-left p-2.5 rounded-lg text-red-400 hover:bg-red-500/20 hover:text-red-300 transition-colors duration-200">
                    <div className="w-5 h-5"><ArrowRightOnRectangleIcon /></div>
                    <span className="font-semibold text-sm">Log Out</span>
                </button>
            </nav>
        </div>
    );
};

const TopBar: React.FC = () => {
  const { user, logout } = useUser();
  const { notifications } = useNotifications();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;

  const location = useLocation();
  const navigate = useNavigate();
  const isDashboard = location.pathname === '/dashboard';

  const handleLogout = () => {
    setIsProfileOpen(false);
    if(window.confirm("Are you sure you want to log out?")){
        logout();
    }
  };
  
  return (
    <>
      <SideMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />
      <header className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between p-4 h-16 bg-white/80 dark:bg-slate-950/50 backdrop-blur-md border-b border-slate-200 dark:border-slate-800/50">
        <div className="w-10">
          {isDashboard ? (
            <button className="p-2 -m-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition" onClick={() => setIsMenuOpen(true)} aria-label="Open menu">
                <Bars3Icon className="h-7 w-7 text-slate-500 dark:text-slate-400" />
            </button>
          ) : (
            <button onClick={() => navigate(-1)} className="p-2 -m-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition" aria-label="Go back">
                <ArrowLeftIcon className="h-7 w-7 text-slate-500 dark:text-slate-400" />
            </button>
          )}
        </div>
        
        <Link to="/dashboard" className="flex items-center gap-2 absolute left-1/2 -translate-x-1/2">
            <Logo className="w-8 h-8 text-primary-500" />
            <h1 className="hidden sm:block text-lg font-bold text-slate-800 dark:text-slate-200 whitespace-nowrap">Nova Learning Hub</h1>
        </Link>
        
        <div className="flex items-center gap-4">
            <Link to="/search" className="p-2 -m-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition" aria-label="Search">
                <MagnifyingGlassIcon className="h-6 w-6 text-slate-500 dark:text-slate-400" />
            </Link>
            <div className="relative">
                <button className="p-2 -m-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition relative" onClick={() => setIsNotificationsOpen(prev => !prev)} aria-label={`Notifications (${unreadCount} unread)`}>
                    <BellIcon className="h-6 w-6 text-slate-500 dark:text-slate-400" />
                    {unreadCount > 0 && <span className="absolute top-0 right-0 block h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white dark:ring-slate-950/50"></span>}
                </button>
                <NotificationPanel isOpen={isNotificationsOpen} onClose={() => setIsNotificationsOpen(false)} />
            </div>
            <div className="relative">
                <button onClick={() => setIsProfileOpen(p => !p)} aria-label="Open user profile menu">
                    <img src={user.avatar} alt="User avatar" className="w-9 h-9 rounded-full border-2 border-slate-300 dark:border-slate-600 hover:border-primary-500 transition"/>
                </button>
                 <ProfileDropdown isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} user={user} onLogout={handleLogout} />
            </div>
        </div>
      </header>
    </>
  );
};

const AppLayout: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen font-sans text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-900">
      <TopBar />
      <main className="flex-grow pt-16 pb-28">
        <Outlet />
      </main>
      <FooterNav />
    </div>
  );
};

const ProtectedRoute: React.FC = () => {
  const { isOnboardingComplete } = useUser();
  if (!isOnboardingComplete) {
    return <Navigate to="/onboarding" replace />;
  }
  return <AppLayout />;
};

const App: React.FC = () => {
  const { isOnboardingComplete } = useUser();

  return (
      <Routes>
        {/* Onboarding route: show if not complete, otherwise redirect to dashboard */}
        <Route 
          path="/onboarding" 
          element={isOnboardingComplete ? <Navigate to="/dashboard" replace /> : <Onboarding />} 
        />
        
        {/* Standalone settings route without footer */}
        <Route path="/settings" element={isOnboardingComplete ? <Settings /> : <Navigate to="/onboarding" />} />
        <Route path="/profile/edit" element={isOnboardingComplete ? <EditProfile /> : <Navigate to="/onboarding" />} />

        {/* Protected app routes */}
        <Route path="/" element={<ProtectedRoute />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="courses" element={<Courses />} />
          <Route path="courses/:courseId" element={<CourseDetail />} />
          <Route path="courses/:courseId/:moduleId/:chapterId" element={<ChapterView />} />
          <Route path="challenges" element={<Challenges />} />
          <Route path="search" element={<Search />} />
          <Route path="profile" element={<Profile />} />
          <Route path="bookmarks" element={<Bookmarks />} />
          <Route path="community" element={<Community />} />
        </Route>
        
        {/* Catch-all 404 route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
  );
};

export default App;