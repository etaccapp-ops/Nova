import React, { useState } from 'react';
import { useParams, Link, Navigate, useNavigate } from 'react-router-dom';
import { COURSES_DATA } from '../constants';
import { ArrowLeftIcon, ChevronDownIcon, ChevronRightIcon } from '../components/Icons';

const CourseDetail: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const navigate = useNavigate();
  const course = COURSES_DATA.find(c => c.id === courseId);
  
  const [openModuleId, setOpenModuleId] = useState<string | null>(course?.modules[0]?.id ?? null);

  if (!course) {
    return <Navigate to="/courses" replace />;
  }
  
  const startLearningPath = course.modules[0]?.chapters[0] 
    ? `/courses/${course.id}/${course.modules[0].id}/${course.modules[0].chapters[0].id}` 
    : '#';

  const totalModules = course.modules.length;
  const totalChapters = course.modules.reduce((acc, module) => acc + module.chapters.length, 0);

  const pattern = `data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E`;
  
  const toggleModule = (moduleId: string) => {
    setOpenModuleId(prevId => (prevId === moduleId ? null : moduleId));
  };

  return (
    <div className="bg-slate-50 dark:bg-slate-900 min-h-screen pb-20">
      <div className="p-4 md:p-6 max-w-lg mx-auto">
        <div className="bg-white dark:bg-slate-800/50 dark:backdrop-blur-sm rounded-2xl shadow-lg overflow-hidden border border-slate-200 dark:border-slate-700">
          
          <div className="relative">
            <div className="aspect-[4/3] w-full relative">
              <img src={course.imageUrl} alt={course.title} className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
              <div className="absolute inset-0" style={{ backgroundImage: `url("${pattern}")` }}></div>
              <div className="absolute inset-0 p-5 sm:p-6 flex flex-col text-white">
                
                <div className="flex justify-between items-start">
                    <button onClick={() => navigate(-1)} className="bg-black/30 text-white rounded-full p-2 hover:bg-black/50 transition-colors z-10">
                        <ArrowLeftIcon className="w-6 h-6" />
                    </button>
                    <div className="flex gap-2">
                        <span className="bg-white/10 text-white text-xs font-semibold px-3 py-1.5 rounded-full backdrop-blur-sm border border-white/20">
                            {totalModules} Modules
                        </span>
                         <span className="bg-white/10 text-white text-xs font-semibold px-3 py-1.5 rounded-full backdrop-blur-sm border border-white/20">
                            {totalChapters} Lessons
                        </span>
                    </div>
                </div>
                
                <div className="flex-grow flex flex-col items-center justify-center">
                  <h1 className="text-4xl sm:text-5xl font-bold text-center drop-shadow-lg">{course.title}</h1>
                  <span className="mt-4 bg-black/40 border border-white/20 text-white text-sm font-bold px-3 py-1 rounded-md backdrop-blur-sm">{course.level}</span>
                </div>
                
                <div className="self-center">
                    <Link to={startLearningPath} className="bg-primary-600 font-bold py-3 px-8 rounded-lg hover:bg-primary-700 transition shadow-lg shadow-black/30 text-white">
                        Start Learning
                    </Link>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 sm:p-6 text-slate-800 dark:text-slate-200 space-y-6">
            <p className="text-slate-600 dark:text-slate-300 text-base">{course.description}</p>

            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-4">Course Content</h2>
              <div className="space-y-2">
                {course.modules.map((module, moduleIndex) => (
                  <div key={module.id} className="bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                    <button 
                        onClick={() => toggleModule(module.id)} 
                        className="w-full flex justify-between items-center p-4 text-left"
                    >
                        <div className="flex items-center gap-3">
                            <span className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center font-bold text-slate-500 dark:text-slate-400 text-sm">
                                {String(moduleIndex + 1).padStart(2, '0')}
                            </span>
                            <span className="font-semibold">{module.title}</span>
                        </div>
                        <ChevronDownIcon className={`w-5 h-5 text-slate-500 transition-transform duration-300 ${openModuleId === module.id ? 'rotate-180' : ''}`} />
                    </button>
                    {openModuleId === module.id && (
                        <div className="pb-2 px-4 space-y-1">
                            {module.chapters.map((chapter, chapterIndex) => (
                                <Link 
                                    key={chapter.id} 
                                    to={`/courses/${course.id}/${module.id}/${chapter.id}`}
                                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700/60 transition-colors"
                                >
                                    <span className="text-sm font-mono text-slate-500">{String(chapterIndex + 1).padStart(2, '0')}</span>
                                    <span className="text-sm flex-grow">{chapter.title}</span>
                                    <ChevronRightIcon className="w-4 h-4 text-slate-400" />
                                </Link>
                            ))}
                        </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default CourseDetail;