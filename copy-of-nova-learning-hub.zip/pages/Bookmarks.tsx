import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useBookmarks } from '../contexts/BookmarkContext';
import { Bookmark } from '../types';
import { ChevronLeftIcon, DocumentTextIcon, TrashIcon, BookmarkIcon as BookmarkIconBase } from '../components/Icons';

const BookmarkCard: React.FC<{ bookmark: Bookmark; onRemove: (chapterId: string) => void; }> = ({ bookmark, onRemove }) => {
    return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 p-5 flex flex-col justify-between">
            <div>
                <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-10 h-10 bg-slate-100 dark:bg-slate-700 rounded-lg flex items-center justify-center">
                        <DocumentTextIcon className="w-6 h-6 text-slate-500" />
                    </div>
                    <div>
                        <p className="font-semibold text-slate-800 dark:text-slate-200 leading-tight">{bookmark.title}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{bookmark.context}</p>
                    </div>
                </div>
            </div>
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                <Link to={`/courses/${bookmark.courseId}/${bookmark.moduleId}/${bookmark.chapterId}`} className="text-sm font-semibold text-primary-500 dark:text-primary-400 hover:underline">
                    Go to Lesson
                </Link>
                <button 
                    onClick={() => onRemove(bookmark.chapterId)} 
                    className="p-2 -m-2 rounded-full text-slate-400 hover:text-red-500 hover:bg-red-500/10 transition-colors"
                    title="Remove bookmark"
                >
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    )
};


const Bookmarks: React.FC = () => {
    const navigate = useNavigate();
    const { bookmarks, removeBookmark } = useBookmarks();

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            <div className="p-4 md:p-6 max-w-5xl mx-auto">
                <h1 className="text-3xl font-bold mb-8 text-slate-900 dark:text-white">All Bookmarks</h1>
                {bookmarks.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {bookmarks.map(b => (
                            <BookmarkCard key={b.chapterId} bookmark={b} onRemove={removeBookmark} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20">
                         <div className="w-20 h-20 mx-auto text-slate-400 dark:text-slate-500"><BookmarkIconBase /></div>
                        <h2 className="text-2xl font-bold mt-4">No Bookmarks Yet</h2>
                        <p className="text-slate-500 dark:text-slate-400 mt-2">You can bookmark lessons by clicking the bookmark icon on any lesson page.</p>
                        <Link to="/courses" className="mt-6 inline-block bg-primary-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-primary-700 transition">
                            Explore Courses
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Bookmarks;