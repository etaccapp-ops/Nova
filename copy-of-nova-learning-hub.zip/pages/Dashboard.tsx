import React from 'react';
import { Link } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { useBookmarks } from '../contexts/BookmarkContext';
import { BookIcon, DocumentTextIcon, BookmarkIcon, TrophyIcon, CheckBadgeIcon, DropIcon, CalendarDaysIcon } from '../components/Icons';

const PieChart: React.FC<{ percentage: number; size?: number }> = ({ percentage, size = 120 }) => {
    const strokeWidth = 12;
    const radius = size / 2 - strokeWidth / 2;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (percentage / 100) * circumference;

    return (
        <div className="relative" style={{ width: size, height: size }}>
            <svg className="w-full h-full transform -rotate-90" viewBox={`0 0 ${size} ${size}`}>
                <circle
                    className="text-slate-200 dark:text-slate-700"
                    stroke="currentColor"
                    strokeWidth={strokeWidth}
                    fill="transparent"
                    r={radius}
                    cx={size / 2}
                    cy={size / 2}
                />
                <circle
                    className="text-primary-500 dark:text-primary-400 drop-shadow-[0_2px_4px_rgba(59,130,246,0.5)]"
                    stroke="currentColor"
                    strokeWidth={strokeWidth}
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    fill="transparent"
                    r={radius}
                    cx={size / 2}
                    cy={size / 2}
                    style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
                />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-3xl font-bold text-slate-800 dark:text-white">{`${percentage}`}<span className="text-lg text-slate-500 dark:text-slate-400">%</span></span>
            </div>
        </div>
    );
};

const ProgressCard: React.FC<{ progress: number, cardBaseStyle: string }> = ({ progress, cardBaseStyle }) => (
    <section className={`${cardBaseStyle} p-6`}>
        <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Overall Progress</h3>
            <Link to="/profile" className="text-sm font-semibold text-primary-500 dark:text-primary-400 hover:underline">
                View Stats
            </Link>
        </div>
        <div className="flex flex-col md:flex-row items-center justify-center gap-6 text-center md:text-left">
            <PieChart percentage={progress} />
            <div className="flex-1">
                <p className="text-slate-600 dark:text-slate-300">You've completed <span className="font-bold text-slate-800 dark:text-white">{progress}%</span> of all courses. Keep up the great work and earn your certificate!</p>
            </div>
        </div>
    </section>
);

const BookmarkedLessons: React.FC<{cardBaseStyle: string}> = ({ cardBaseStyle }) => {
    const { bookmarks } = useBookmarks();
    const recentBookmarks = bookmarks.slice(0, 4);

    return (
        <section>
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white">Recent Bookmarks</h3>
                {bookmarks.length > 0 && (
                    <Link to="/bookmarks" className="text-sm font-semibold text-primary-500 dark:text-primary-400 hover:underline">
                        View All
                    </Link>
                )}
            </div>
             
            {recentBookmarks.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {recentBookmarks.map(bookmark => (
                         <Link to={`/courses/${bookmark.courseId}/${bookmark.moduleId}/${bookmark.chapterId}`} key={bookmark.chapterId} className={`block p-4 rounded-xl hover:scale-105 transition-transform duration-200 ${cardBaseStyle}`}>
                            <div className="flex items-center gap-4">
                                <div className="flex-shrink-0 w-10 h-10 bg-slate-200 dark:bg-slate-700 rounded-lg flex items-center justify-center">
                                    <DocumentTextIcon className="w-6 h-6 text-slate-500" />
                                </div>
                                <div>
                                    <p className="font-semibold text-slate-800 dark:text-slate-200 leading-tight">{bookmark.title}</p>
                                    <p className="text-xs text-slate-500 dark:text-slate-400">{bookmark.context}</p>
                                </div>
                            </div>
                        </Link>
                    ))}
                </div>
            ) : (
                <div className={`${cardBaseStyle} text-center py-12`}>
                    <div className="w-12 h-12 mx-auto text-slate-400"><BookmarkIcon /></div>
                    <p className="text-slate-500 dark:text-slate-400 mt-2">You haven't bookmarked any lessons yet.</p>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Click the bookmark icon on a lesson page to save it here.</p>
                </div>
            )}
        </section>
    )
};

const LearningActivityGraph = () => {
    const days = Array.from({ length: 182 }, (_, i) => { // Approx 26 weeks for a 26x7 grid
        const activity = Math.random();
        let color = 'bg-slate-200 dark:bg-slate-700/50';
        if (activity > 0.8) color = 'bg-green-400';
        else if (activity > 0.6) color = 'bg-green-500';
        else if (activity > 0.4) color = 'bg-green-600';
        else if (activity > 0.2) color = 'bg-green-700';
        const activityLevel = Math.floor(activity * 10);
        return <div key={i} className={`aspect-square w-full rounded-sm ${color}`} title={`Activity: ${activityLevel}/10`}></div>;
    });

    return <div className="grid grid-cols-[repeat(26,minmax(0,1fr))] gap-1.5">{days}</div>;
};


const Dashboard: React.FC = () => {
  const { user } = useUser();
  
  const cardBaseStyle = "bg-white dark:bg-slate-800/50 dark:backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700";

  return (
    <div className="bg-slate-50 dark:bg-gradient-to-b from-slate-950 to-slate-900 min-h-screen">
      <div className="p-4 md:p-6 space-y-8">
        <section>
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Welcome back, {user.name}!</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Ready to continue your learning journey?</p>
        </section>

        <Link to="/courses" className="block group">
            <section className={`${cardBaseStyle} p-6 text-center transition-all duration-300 ease-in-out group-hover:scale-[1.03] group-hover:shadow-xl group-hover:border-primary-500/50 dark:group-hover:border-primary-400/50`}>
                <div className="w-20 h-20 mx-auto text-primary-500 dark:text-primary-400 mb-3 transition-transform duration-300 group-hover:scale-110">
                    <BookIcon />
                </div>
                <h3 className="text-xl font-bold">Start Your Journey</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">Explore our courses and begin!</p>
            </section>
        </Link>
        
        <ProgressCard progress={user.certificateProgress} cardBaseStyle={cardBaseStyle} />

        <section className={`${cardBaseStyle} p-6`}>
            <h3 className="font-bold text-xl mb-4">Learning Activity</h3>
            <LearningActivityGraph />
            <p className="text-xs text-slate-500 mt-3 text-center">Mock data representing last six months' activity.</p>
        </section>

        <BookmarkedLessons cardBaseStyle={cardBaseStyle} />

        <section className="grid grid-cols-2 gap-6">
          <div className={`${cardBaseStyle} p-6`}>
            <p className="text-slate-500 dark:text-slate-400 text-sm">Day Streak</p>
            <p className="text-5xl font-bold">{user.dailyStreak}</p>
            <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Longest streak: {user.longestStreak}</p>
          </div>
          <div className={`${cardBaseStyle} p-6`}>
            <p className="text-slate-500 dark:text-slate-400 text-sm">Total Points</p>
            <p className="text-5xl font-bold">{user.points}</p>
             <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Top 10%</p>
          </div>
        </section>

        <footer className="text-center text-xs text-slate-500 py-4 mt-4 border-t border-slate-200 dark:border-slate-800">
            <p>🇪🇹 Proudly Made in Ethiopia</p>
            <p className="my-1">---------</p>
            <p>Nova Tech Labs</p>
            <p>Designed by: <a href="mailto:ambesaw05@gmail.com" className="underline hover:text-slate-300 dark:hover:text-slate-100">Andualem T.</a></p>
            <p>October 2025, Addis Ababa, Ethiopia</p>
        </footer>
      </div>
    </div>
  );
};

export default Dashboard;