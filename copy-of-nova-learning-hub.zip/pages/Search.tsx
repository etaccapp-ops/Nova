import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { COURSES_DATA } from '../constants';
import { Course, Module, Chapter } from '../types';
import { MagnifyingGlassIcon, BookOpenIcon, DocumentTextIcon, Squares2X2Icon } from '../components/Icons';

type SearchResultType = 'Course' | 'Module' | 'Chapter';
type FilterType = 'All' | SearchResultType;

interface SearchResult {
  type: SearchResultType;
  title: string;
  path: string;
  context: string;
  snippet?: string;
}

// Helper to create a highlighted snippet from chapter content
const createSnippet = (content: string, term: string): string => {
  const plainText = content.replace(/<[^>]+>/g, ' '); // Strip HTML tags
  const termLower = term.toLowerCase();
  const contentLower = plainText.toLowerCase();
  
  const index = contentLower.indexOf(termLower);
  if (index === -1) {
    return plainText.substring(0, 100) + '...';
  }

  const start = Math.max(0, index - 40);
  const end = Math.min(plainText.length, index + term.length + 40);
  let snippet = plainText.substring(start, end);

  // Highlight the term
  const regex = new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
  snippet = snippet.replace(regex, `<strong class="text-primary-500 dark:text-primary-400 bg-primary-500/10 dark:bg-primary-500/20 rounded-md px-1 py-0.5">$1</strong>`);
  
  return `...${snippet}...`;
};

const SearchResultItem: React.FC<{ result: SearchResult }> = ({ result }) => {
  const icon = result.type === 'Course' 
    ? <BookOpenIcon /> 
    : result.type === 'Module'
    ? <Squares2X2Icon />
    : <DocumentTextIcon />;

  return (
    <Link to={result.path} className="block p-4 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-xl shadow-md hover:shadow-lg transition-all duration-200 border border-slate-200 dark:border-slate-700">
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-8 h-8 text-slate-400 mt-1">{icon}</div>
        <div>
          <p className="font-bold text-primary-600 dark:text-primary-400">{result.title}</p>
          <p className="text-xs text-slate-500">{result.context}</p>
          {result.snippet && (
            <p 
              className="mt-2 text-sm text-slate-600 dark:text-slate-300"
              dangerouslySetInnerHTML={{ __html: result.snippet }} 
            />
          )}
        </div>
      </div>
    </Link>
  );
};

const FilterButton: React.FC<{label: FilterType, count: number, activeFilter: FilterType, setFilter: (filter: FilterType) => void}> = ({label, count, activeFilter, setFilter}) => {
    const isActive = label === activeFilter;
    return (
        <button
            onClick={() => setFilter(label)}
            className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-200 border flex items-center ${
                isActive 
                ? 'bg-primary-600 text-white shadow border-primary-700 dark:border-primary-500' 
                : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600 border-slate-300 dark:border-slate-600'
            }`}
        >
            {label}
            <span className={`ml-1.5 text-xs px-1.5 py-0.5 rounded-full ${isActive ? 'bg-white/20' : 'bg-slate-300 dark:bg-slate-600'}`}>{count}</span>
        </button>
    )
}

const Search: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<FilterType>('All');

  const allResults = useMemo<SearchResult[]>(() => {
    if (!searchTerm.trim()) {
      return [];
    }
    
    const lowerCaseTerm = searchTerm.toLowerCase();
    const results: SearchResult[] = [];

    COURSES_DATA.forEach((course: Course) => {
      if (course.title.toLowerCase().includes(lowerCaseTerm) || course.description.toLowerCase().includes(lowerCaseTerm)) {
        results.push({
          type: 'Course',
          title: course.title,
          path: `/courses/${course.id}`,
          context: 'Course',
          snippet: course.description
        });
      }
      course.modules.forEach((module: Module) => {
        if (module.title.toLowerCase().includes(lowerCaseTerm)) {
            results.push({ type: 'Module', title: module.title, path: `/courses/${course.id}`, context: `In Course: ${course.title}`, snippet: `${module.chapters.length} chapters` });
        }
        module.chapters.forEach((chapter: Chapter) => {
          if (chapter.title.toLowerCase().includes(lowerCaseTerm) || chapter.content.toLowerCase().includes(lowerCaseTerm)) {
             results.push({ type: 'Chapter', title: chapter.title, path: `/courses/${course.id}/${module.id}/${chapter.id}`, context: `${course.title} > ${module.title}`, snippet: createSnippet(chapter.content, searchTerm) });
          }
        });
      });
    });
    return results;
  }, [searchTerm]);

  const counts = useMemo(() => ({
    All: allResults.length,
    Course: allResults.filter(r => r.type === 'Course').length,
    Module: allResults.filter(r => r.type === 'Module').length,
    Chapter: allResults.filter(r => r.type === 'Chapter').length,
  }), [allResults]);

  const filteredResults = useMemo<SearchResult[]>(() => {
    if (filter === 'All') return allResults;
    return allResults.filter(result => result.type === filter);
  }, [allResults, filter]);

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-slate-900 dark:text-white pb-4 border-b border-slate-200 dark:border-slate-700">Search</h1>
      
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <MagnifyingGlassIcon className="h-5 w-5 text-slate-400" />
        </div>
        <input 
            type="search" 
            placeholder="Search courses, lessons, and more..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-full border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-primary-500 transition shadow-sm"
        />
      </div>

      <div className="flex justify-center gap-2 flex-wrap">
        <FilterButton label="All" count={counts.All} activeFilter={filter} setFilter={setFilter} />
        <FilterButton label="Course" count={counts.Course} activeFilter={filter} setFilter={setFilter} />
        <FilterButton label="Module" count={counts.Module} activeFilter={filter} setFilter={setFilter} />
        <FilterButton label="Chapter" count={counts.Chapter} activeFilter={filter} setFilter={setFilter} />
      </div>

      <div className="space-y-5">
        {searchTerm && filteredResults.length > 0 && (
          <p className="text-sm text-slate-500 dark:text-slate-400 pb-2">Found {filteredResults.length} result{filteredResults.length > 1 ? 's' : ''} for "{searchTerm}"</p>
        )}

        {searchTerm && filteredResults.length === 0 && (
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold">No Results Found</h3>
            <p className="text-slate-500 mt-1">Try a different search term or filter.</p>
          </div>
        )}
        
        {!searchTerm && (
           <div className="text-center py-12">
            <h3 className="text-lg font-semibold">Search for anything</h3>
            <p className="text-slate-500 mt-1">Find courses, modules, lessons, and code challenges.</p>
          </div>
        )}

        {filteredResults.map((result, index) => (
          <SearchResultItem key={`${result.path}-${index}`} result={result} />
        ))}
      </div>
    </div>
  );
};

export default Search;