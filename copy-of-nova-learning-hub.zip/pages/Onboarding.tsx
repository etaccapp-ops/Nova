import React, { useState } from 'react';
import { useUser } from '../contexts/UserContext';
import { Logo } from '../components/Icons';

const AVATARS = [
    "https://i.pravatar.cc/150?u=a042581f4e29026704d",
    "https://i.pravatar.cc/150?u=a042581f4e29026704e",
    "https://i.pravatar.cc/150?u=a042581f4e29026704f",
    "https://i.pravatar.cc/150?u=a042581f4e29026704a",
    "https://i.pravatar.cc/150?u=a042581f4e29026704b",
    "https://i.pravatar.cc/150?u=a042581f4e29026704c",
];

const Onboarding: React.FC = () => {
    const [step, setStep] = useState(1);
    const [name, setName] = useState('');
    const [selectedAvatar, setSelectedAvatar] = useState(AVATARS[0]);
    const { completeOnboarding } = useUser();

    const handleNext = () => {
        if (step === 1 && name.trim() !== '') {
            setStep(2);
        } else if (step === 2) {
            completeOnboarding(name, selectedAvatar);
        }
    };

    const handleBack = () => {
        if (step > 1) {
            setStep(step - 1);
        }
    }

    const handleGuestLogin = () => {
        completeOnboarding('Guest', AVATARS[0]);
    };

    return (
        <div className="flex flex-col items-center justify-between min-h-screen bg-slate-900 text-white p-4">
            <div className="w-full max-w-sm text-center flex-grow flex flex-col justify-center">
                {step === 1 && (
                    <div className="animate-fade-in">
                        <Logo className="w-20 h-20 mx-auto mb-4 text-primary-500" />
                        <h1 className="text-4xl font-bold mb-2">Welcome to Nova!</h1>
                        <p className="text-sm font-bold text-orange-500 mb-2">🇪🇹 Proudly made in Ethiopia!</p>
                        <p className="text-slate-400 mb-8">What should we call you?</p>
                        <input
                            type="text"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="Enter your name"
                            className="w-full px-4 py-3 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                        <button
                            onClick={handleNext}
                            disabled={!name.trim()}
                            className="w-full mt-6 bg-primary-600 text-white font-bold py-3 rounded-lg hover:bg-primary-700 disabled:bg-primary-500/50 disabled:cursor-not-allowed transition"
                        >
                            Next
                        </button>
                        <div className="relative my-6">
                            <div className="absolute inset-0 flex items-center" aria-hidden="true">
                                <div className="w-full border-t border-slate-700" />
                            </div>
                            <div className="relative flex justify-center">
                                <span className="bg-slate-900 px-2 text-sm text-slate-500">OR</span>
                            </div>
                        </div>
                        <button
                            onClick={handleGuestLogin}
                            className="w-full bg-slate-700 text-white font-bold py-3 rounded-lg hover:bg-slate-600 transition flex items-center justify-center gap-2"
                        >
                            👤 Continue as Guest
                        </button>
                    </div>
                )}

                {step === 2 && (
                     <div className="animate-fade-in">
                        <h1 className="text-3xl font-bold mb-2">Pick Your Avatar</h1>
                        <p className="text-slate-400 mb-8">Choose an avatar that represents you.</p>
                        
                        <div className="grid grid-cols-3 gap-4 mb-8">
                            {AVATARS.map((avatarUrl) => (
                                <button key={avatarUrl} onClick={() => setSelectedAvatar(avatarUrl)}>
                                    <img 
                                        src={avatarUrl} 
                                        alt="Avatar option"
                                        className={`w-20 h-20 rounded-full mx-auto border-4 transition ${selectedAvatar === avatarUrl ? 'border-primary-500 scale-110' : 'border-transparent'}`}
                                    />
                                </button>
                            ))}
                        </div>
                        
                        <div className="flex gap-4">
                            <button
                                onClick={handleBack}
                                className="w-full bg-slate-700 text-white font-bold py-3 rounded-lg hover:bg-slate-600 transition"
                            >
                                Back
                            </button>
                            <button
                                onClick={handleNext}
                                className="w-full bg-primary-600 text-white font-bold py-3 rounded-lg hover:bg-primary-700 transition"
                            >
                                Finish Setup
                            </button>
                        </div>
                    </div>
                )}
            </div>
             <footer className="text-center text-xs text-slate-500 py-4 flex-shrink-0">
                <p>🇪🇹 Proudly Made in Ethiopia</p>
                <p className="my-1">---------</p>
                <p>Nova Tech Labs</p>
                <p>Designed by: <a href="mailto:ambesaw05@gmail.com" className="underline hover:text-slate-300">Andualem T.</a></p>
                <p>October 2025, Addis Ababa, Ethiopia</p>
            </footer>
        </div>
    );
};

export default Onboarding;