import React from 'react';
import { Link } from 'react-router-dom';
import { COURSES_DATA } from '../constants';
import { Course } from '../types';

const CourseCard: React.FC<{ course: Course }> = ({ course }) => {
  const pattern = `data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E`;

  return (
    <Link
      to={`/courses/${course.id}`}
      className="group block bg-white dark:bg-slate-800 rounded-2xl transition-all duration-300 ease-in-out overflow-hidden border border-slate-200 dark:border-slate-700 hover:border-primary-500 dark:hover:border-primary-400 hover:scale-[1.02] hover:shadow-2xl"
    >
      <div className="relative h-52">
        {course.imageUrl ? (
          <img
            src={course.imageUrl}
            alt={`${course.title} cover`}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-slate-700"></div>
        )}
        <div className="absolute inset-0 bg-slate-800/70 mix-blend-multiply group-hover:bg-slate-800/60 transition-colors duration-300"></div>
        <div className="absolute inset-0 bg-black/30" style={{ backgroundImage: `url("${pattern}")` }}></div>
        
        <div className="absolute inset-0 p-5 flex flex-col justify-between text-white">
          <div>
            <span className="bg-black/40 border border-white/20 text-white text-xs font-bold px-2.5 py-1 rounded-md backdrop-blur-sm">{course.level}</span>
          </div>
          <h2 className="text-2xl font-bold text-white drop-shadow-md">{course.title}</h2>
        </div>
      </div>
      <div className="p-5">
        <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{course.description}</p>
      </div>
    </Link>
  );
};


const Courses: React.FC = () => {
  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-slate-900 dark:text-white">Courses</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {COURSES_DATA.map(course => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>
    </div>
  );
};

export default Courses;