import React from 'react';
import { Link } from 'react-router-dom';
import { UsersIcon } from '../components/Icons';

const Community: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <div className="w-20 h-20 text-slate-400 dark:text-slate-500">
                <UsersIcon />
            </div>
            <h2 className="text-2xl font-semibold mt-4 text-slate-800 dark:text-slate-200">Community Hub Coming Soon!</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-2 max-w-md">Connect with other learners, ask questions, and share your progress. We're building a space for collaboration and growth.</p>
            <Link
                to="/dashboard"
                className="mt-6 bg-primary-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-primary-700 transition"
            >
                Back to Dashboard
            </Link>
        </div>
    );
};

export default Community;