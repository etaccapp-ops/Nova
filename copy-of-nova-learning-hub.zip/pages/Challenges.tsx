import React, { useState } from 'react';
import { CodeEditor } from '../components/CodeEditor';
import { LAB_CHALLENGES } from '../constants';
import { LabChallenge } from '../types';

// START: Added Preview Components for "Motherfucking Website" Challenges
const MotherfuckingWebsitePreview: React.FC = () => {
    return (
      <div className="bg-white text-black font-serif p-8 max-w-3xl mx-auto border border-gray-300 shadow-lg text-left">
        <h1 className="text-4xl font-bold mb-4">This is a motherfucking website.</h1>
        <p className="mb-6">And it's fucking perfect.</p>
        
        <h2 className="text-2xl font-bold mb-4">Seriously, what the fuck else do you want?</h2>
        <p className="mb-4">
          You probably build websites and think your shit is special. You think your 13 megabyte parallax-ative home page is going to get you some fucking Awwward banner you can glue to the top corner of your site. You think your 40-pound jQuery file and 83 polyfills give IE7 a boner because it finally has box-shadow. Wrong, motherfucker. Let me describe your perfect-ass website:
        </p>
        <ul className="list-disc list-inside mb-6 space-y-1 pl-4">
          <li>Shit's lightweight and loads fast</li>
          <li>Fits on all your shitty screens</li>
          <li>Looks the same in all your shitty browsers</li>
          <li>The motherfucker's accessible to every asshole that visits your site</li>
          <li>Shit's legible and gets your fucking point across (if you had one instead of just 5mb pics of hipsters drinking coffee)</li>
        </ul>
        <p className="mb-4">Well guess what, motherfucker:</p>
        <p className="mb-6">
          You. Are. Over-designing. Look at this shit. It's a motherfucking website. Why the fuck do you need to animate a fucking trendy-ass banner flag when I hover over that useless piece of shit? You spent hours on it and added 80 kilobytes to your fucking site, and some motherfucker jabbing at it on their iPad with fat sausage fingers will never see that shit. Not to mention blind people will never see that shit, but they don't see any of your shitty shit.
        </p>
        <p className="mb-6">You never knew it, but this is your perfect website. Here's why.</p>
  
        <h2 className="text-2xl font-bold mb-4">It's fucking lightweight</h2>
        <p className="mb-6">
          This entire page weighs less than the gradient-meshed facebook logo on your fucking Wordpress site. Did you seriously load 100kb of jQuery UI just so you could animate the fucking background color of a div? You loaded all 7 fontfaces of a shitty webfont just so you could say "Hi." at 100px height at the beginning of your site? You piece of shit.
        </p>
  
        <h2 className="text-2xl font-bold mb-4">It's responsive</h2>
        <p className="mb-6">
          You dumbass. You thought you needed media queries to be responsive, but no. Responsive means that it responds to whatever motherfucking screensize it's viewed on. This site doesn't care if you're on an iMac or a motherfucking Tamagotchi.
        </p>
  
        <h2 className="text-2xl font-bold mb-4">It fucking works</h2>
        <p className="mb-6">
          Look at this shit. You can read it ... that is, if you can read, motherfucker. It makes sense. It has motherfucking hierarchy. It's using HTML5 tags so you and your bitch-ass browser know what the fuck's in this fucking site. That's semantics, motherfucker.
        </p>
      </div>
    );
};
  
const BetterMotherfuckingWebsitePreview: React.FC = () => {
    const style: React.CSSProperties = {
      fontFamily: 'sans-serif',
      maxWidth: '40em',
      margin: '0 auto',
      padding: '2em',
      lineHeight: '1.5',
      fontSize: '16px',
      color: '#333',
      backgroundColor: '#fff',
    };
  
    return (
      <div style={style} className="border border-gray-300 shadow-lg text-left">
        <h1 style={{ lineHeight: 1.2, fontSize: '2.5em', fontWeight: 'bold' }}>This is still a motherfucking website.</h1>
        <p>And it's more fucking perfect than the last guy's.</p>
        
        <h2 style={{ lineHeight: 1.2, fontSize: '2em', marginTop: '2em', fontWeight: 'bold' }}>Seriously, it takes minimal fucking effort to improve this shit.</h2>
        <p>7 fucking declarations.</p>
        <p>That's how much CSS it took to turn that <a href="#">grotesque pile of shit</a> into this easy-to-read masterpiece. It's so fucking simple and it still has all the glory of the original perfect-ass website:</p>
        <ul style={{ listStyle: 'disc', paddingLeft: '2em', marginTop: '1em', marginBottom: '1em' }}>
          <li>Shit's <em>still</em> lightweight and loads fast</li>
          <li>Still fits on all your shitty screens</li>
          <li>Still looks the same in all your shitty browsers</li>
          <li>The motherfucker's <em>still</em> accessible to every asshole that visits your site</li>
          <li>Shit's <em>still</em> legible and gets your fucking point across</li>
        </ul>
  
        <h2 style={{ lineHeight: 1.2, fontSize: '2em', marginTop: '2em', fontWeight: 'bold' }}>And guess what, motherfucker:</h2>
        <p>You never knew it, but it's easy to improve readability on your site. Here's how.</p>
  
        <h3 style={{ lineHeight: 1.2, fontSize: '1.5em', marginTop: '1.5em', fontWeight: 'bold' }}>Let it breathe</h3>
        <p>Look at lines 1 and 2 of some shitty website you're building. Assuming they're not married they probably shouldn't be humping. The defaults are trash -- pick a minimum line-height: 1.4 for body copy. Headings should be tighter. If you can't see that...piss off.</p>
        <p>If your text hits the side of the browser, fuck off forever. You ever see a book like that? Yes? What a shitty book.</p>
        
        <h3 style={{ lineHeight: 1.2, fontSize: '1.5em', marginTop: '1.5em', fontWeight: 'bold' }}>A little less contrast</h3>
        <p>Black on white? How often do you see that kind of contrast in real life? Tone it down a bit, asshole. I would've even made this site's background a nice #EEEEEE if I wasn't so focused on keeping declarations to a lean 7 fucking lines.</p>
        
        <h3 style={{ lineHeight: 1.2, fontSize: '1.5em', marginTop: '1.5em', fontWeight: 'bold' }}>Size Matters</h3>
        <p>I know your partner says otherwise, but it's true. Bump that body copy to render close to 16px or more. Smaller type works well for print, not the screen.</p>
        
        <h3 style={{ lineHeight: 1.2, fontSize: '1.5em', marginTop: '1.5em', fontWeight: 'bold' }}>Line-width, motherfucker</h3>
        <p>Looking at an LCD screen is strainful enough. Don't make me read a line of text that's 200 fucking characters long. Keep it to a nice 60-80 and users might actually read more than one sentence of your worthless dribble.</p>
        
        <hr style={{ margin: '3em 0', border: 0, borderTop: '1px solid #ccc' }} />
        
        <p>Inspired by the geniuses behind <a href="#">motherfuckingwebsite.com</a> and <a href="#">txti</a>.</p>
      </div>
    );
};
  
const PREVIEW_COMPONENTS: { [key: string]: React.FC } = {
    MotherfuckingWebsitePreview,
    BetterMotherfuckingWebsitePreview,
};
// END: Added Preview Components


const Challenges: React.FC = () => {
    const [selectedChallenge, setSelectedChallenge] = useState<LabChallenge>(LAB_CHALLENGES[0]);

    const handleChallengeSelect = (challengeId: string) => {
        const challenge = LAB_CHALLENGES.find(c => c.id === challengeId);
        if (challenge) {
            setSelectedChallenge(challenge);
        }
    };

    return (
        <div className="p-4 md:p-6 space-y-6 flex flex-col h-screen max-h-screen">
            <div className="flex-shrink-0">
                <div className="pb-4 border-b border-slate-200 dark:border-slate-700">
                    <h1 className="text-3xl font-bold text-slate-900 dark:text-white">Coding Labs</h1>
                    <p className="text-slate-500 dark:text-slate-400 mt-1">Test your skills by recreating designs and components.</p>
                </div>
                
                <div className="py-4">
                    <label htmlFor="challenge-select" className="sr-only">Select a Challenge</label>
                    <select
                        id="challenge-select"
                        value={selectedChallenge.id}
                        onChange={(e) => handleChallengeSelect(e.target.value)}
                        className="w-full md:w-auto px-4 py-2 text-sm font-semibold rounded-lg transition-colors duration-200 border bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    >
                        {LAB_CHALLENGES.map(challenge => (
                            <option key={challenge.id} value={challenge.id}>
                                {challenge.title}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            <div className="grid grid-cols-1 gap-6 flex-shrink-0">
                <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 space-y-4">
                    <div>
                        <span className={`capitalize inline-block px-2 py-1 text-xs font-bold rounded-full border ${
                            selectedChallenge.level === 'easy' ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300 border-green-300/50' :
                            selectedChallenge.level === 'intermediate' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300 border-yellow-300/50' :
                            'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300 border-red-300/50'
                        }`}>{selectedChallenge.level}</span>
                        <h2 className="text-2xl font-bold mt-2">{selectedChallenge.title}</h2>
                        <p className="text-slate-500 dark:text-slate-400 mt-2">{selectedChallenge.description}</p>
                        
                        {selectedChallenge.requirements && selectedChallenge.requirements.length > 0 && (
                            <div className="mt-4">
                                <h3 className="font-semibold text-sm text-slate-600 dark:text-slate-300">Requirements:</h3>
                                <ul className="list-disc list-inside text-sm text-slate-500 dark:text-slate-400 space-y-1 mt-1">
                                    {selectedChallenge.requirements.map((req, i) => <li key={i}>{req}</li>)}
                                </ul>
                            </div>
                        )}
                        
                        {selectedChallenge.referenceItems && selectedChallenge.referenceItems.length > 0 && (
                            <div className="mt-4">
                                <h3 className="font-semibold text-sm text-slate-600 dark:text-slate-300">Reference:</h3>
                                {selectedChallenge.referenceItems.map((item, i) => {
                                    if (item.type === 'image') {
                                        return (
                                            <div key={i} className="mt-2">
                                                <img src={item.url} alt={item.description} className="rounded-lg border border-slate-200 dark:border-slate-700 max-w-sm" />
                                                <p className="text-xs text-center text-slate-500 mt-1">{item.description}</p>
                                            </div>
                                        );
                                    }
                                    if (item.type === 'component') {
                                        const PreviewComponent = PREVIEW_COMPONENTS[item.componentId];
                                        return PreviewComponent ? (
                                            <div key={i} className="mt-2">
                                                <div className="bg-slate-100 dark:bg-slate-900 p-4 rounded-lg overflow-x-auto">
                                                   <PreviewComponent />
                                                </div>
                                                <p className="text-xs text-center text-slate-500 mt-1">{item.description}</p>
                                            </div>
                                        ) : null;
                                    }
                                    return null;
                                })}
                            </div>
                        )}

                        {selectedChallenge.hint && (
                           <div className="mt-4 bg-blue-50 dark:bg-slate-800/60 border-l-4 border-blue-400 p-3 rounded-r-lg">
                                <p className="text-sm text-blue-800 dark:text-blue-200"><strong>Hint:</strong> {selectedChallenge.hint}</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <div className="flex-grow min-h-0">
                <CodeEditor challenge={selectedChallenge} />
            </div>
        </div>
    );
};

// Fix: Add default export for the Challenges component
export default Challenges;
