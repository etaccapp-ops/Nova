import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { ChevronLeftIcon } from '../components/Icons';

const AVATARS = [
    "https://i.pravatar.cc/150?u=a042581f4e29026704d", "https://i.pravatar.cc/150?u=a042581f4e29026704e",
    "https://i.pravatar.cc/150?u=a042581f4e29026704f", "https://i.pravatar.cc/150?u=a042581f4e29026704a",
    "https://i.pravatar.cc/150?u=a042581f4e29026704b", "https://i.pravatar.cc/150?u=a042581f4e29026704c",
];

const EditProfile: React.FC = () => {
    const { user, setUser } = useUser();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        name: user.name,
        title: user.title,
        avatar: user.avatar,
    });
    const [isSaved, setIsSaved] = useState(false);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleAvatarSelect = (avatarUrl: string) => {
        setFormData(prev => ({ ...prev, avatar: avatarUrl }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setUser(formData);
        setIsSaved(true);
        setTimeout(() => {
            setIsSaved(false);
            navigate('/profile');
        }, 1500);
    };

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            <header className="flex items-center p-4 border-b border-slate-200 dark:border-slate-800 relative">
                <button onClick={() => navigate(-1)} className="p-2 -m-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                    <ChevronLeftIcon className="w-6 h-6" />
                </button>
                <h1 className="text-xl font-bold absolute left-1/2 -translate-x-1/2">Edit Profile</h1>
            </header>

            <form onSubmit={handleSubmit} className="p-4 md:p-6 space-y-8 max-w-lg mx-auto">
                <div className="flex flex-col items-center space-y-5">
                    <img src={formData.avatar} alt="Current Avatar" className="w-28 h-28 rounded-full border-4 border-primary-500 shadow-lg" />
                    <h2 className="text-lg font-semibold">Change Avatar</h2>
                    <div className="grid grid-cols-6 gap-3">
                        {AVATARS.map(avatar => (
                            <button key={avatar} type="button" onClick={() => handleAvatarSelect(avatar)} className="focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 rounded-full">
                                <img
                                    src={avatar}
                                    alt="Avatar option"
                                    className={`w-12 h-12 rounded-full border-2 transition-transform duration-200 hover:scale-110 ${formData.avatar === avatar ? 'border-primary-500' : 'border-slate-300 dark:border-slate-600'}`}
                                />
                            </button>
                        ))}
                    </div>
                </div>

                <div className="space-y-6">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">Name</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                    </div>
                    <div>
                        <label htmlFor="title" className="block text-sm font-medium text-slate-500 dark:text-slate-400 mb-2">Title</label>
                        <input
                            type="text"
                            id="title"
                            name="title"
                            value={formData.title}
                            onChange={handleInputChange}
                            placeholder="e.g., Student, Aspiring Developer"
                            className="w-full px-4 py-3 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                    </div>
                </div>

                <button
                    type="submit"
                    className={`w-full font-bold py-3 rounded-lg transition-colors text-white border ${isSaved ? 'bg-green-600 border-green-500' : 'bg-primary-600 hover:bg-primary-700 border-primary-700 dark:border-primary-500'}`}
                    disabled={isSaved}
                >
                    {isSaved ? 'Saved!' : 'Save Changes'}
                </button>
            </form>
        </div>
    );
};

export default EditProfile;