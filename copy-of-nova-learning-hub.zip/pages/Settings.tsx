import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import { useUser } from '../contexts/UserContext';
import { useNotifications } from '../contexts/NotificationContext';
import { ChevronLeftIcon, SunIcon, MoonIcon, BellIcon, TrashIcon, ArrowRightOnRectangleIcon, CheckBadgeIcon } from '../components/Icons';

type ThemeColor = 'blue' | 'green' | 'purple' | 'orange';
const THEME_COLORS: { name: ThemeColor, color: string }[] = [
    { name: 'blue', color: 'bg-blue-500' },
    { name: 'green', color: 'bg-green-500' },
    { name: 'purple', color: 'bg-purple-500' },
    { name: 'orange', color: 'bg-orange-500' },
];

const Settings: React.FC = () => {
    const navigate = useNavigate();
    const { theme, toggleTheme, themeColor, setThemeColor } = useTheme();
    const { logout } = useUser();
    const { reminderTime, setReminderTime, scheduleReminder } = useNotifications();
    
    const [notificationPermission, setNotificationPermission] = useState(Notification.permission);
    const [isSaved, setIsSaved] = useState(false);

    useEffect(() => {
        // Use the modern Permissions API if available
        if ('permissions' in navigator) {
            let permissionStatus: PermissionStatus;

            const handlePermissionChange = () => {
                setNotificationPermission(permissionStatus.state);
            };

            navigator.permissions.query({ name: 'notifications' }).then((status) => {
                permissionStatus = status;
                setNotificationPermission(status.state);
                status.onchange = handlePermissionChange;
            });

            return () => {
                if (permissionStatus) {
                    permissionStatus.onchange = null;
                }
            };
        } else {
            // Fallback for older browsers: check periodically
            const interval = setInterval(() => {
                setNotificationPermission(Notification.permission);
            }, 1000);
            return () => clearInterval(interval);
        }
    }, []);

    const requestNotificationPermission = async () => {
      // The `onchange` event from the Permissions API will handle state updates automatically
      const permission = await Notification.requestPermission();
      // For browsers without Permissions API, we manually update state
      setNotificationPermission(permission);
    };

    const handleSetReminder = async () => {
        if (!reminderTime) {
            alert("Please select a time for the reminder.");
            return;
        }
    
        // Handle case where permission is already denied
        if (notificationPermission === 'denied') {
            alert("Notifications are blocked. Please enable them in your browser's site settings to receive reminders.");
            return;
        }
    
        // Handle case where permission is already granted
        if (notificationPermission === 'granted') {
            scheduleReminder(reminderTime);
            setIsSaved(true);
            setTimeout(() => setIsSaved(false), 2000);
            return;
        }
    
        // Handle case where we need to ask for permission. This will trigger the native modal.
        if (notificationPermission === 'default') {
            const permission = await Notification.requestPermission();
            setNotificationPermission(permission); // Update state for UI consistency

            if (permission === 'granted') {
                scheduleReminder(reminderTime);
                setIsSaved(true);
                setTimeout(() => setIsSaved(false), 2000);
            } else {
                // Inform user if they denied the permission right away.
                alert("You've denied notification permissions. To receive reminders, you will need to enable them in your browser's site settings.");
            }
        }
    };

    const handleReset = () => {
        if(window.confirm("Are you sure you want to reset all your progress? This action cannot be undone.")){
            logout();
        }
    };
    
    const handleLogout = () => {
        if(window.confirm("Are you sure you want to log out?")){
            logout();
        }
    };
    
    const sectionCardStyle = "bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700";

    return (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            <header className="flex items-center p-4 border-b border-slate-200 dark:border-slate-800 relative">
                <button onClick={() => navigate(-1)} className="p-2 -m-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                    <ChevronLeftIcon className="w-6 h-6" />
                </button>
                <h1 className="text-xl font-bold absolute left-1/2 -translate-x-1/2">App Settings</h1>
            </header>

            <div className="p-4 md:p-6 max-w-2xl mx-auto space-y-8">
                {/* Appearance Section */}
                <section>
                    <h2 className="text-sm font-bold uppercase text-slate-500 dark:text-slate-400 mb-3 px-2">Appearance</h2>
                    <div className={`${sectionCardStyle} p-6 space-y-6`}>
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                {theme === 'light' ? <SunIcon className="w-6 h-6 text-yellow-500" /> : <MoonIcon className="w-6 h-6 text-blue-400" />}
                                <span className="font-semibold">Theme</span>
                            </div>
                            <div className="flex items-center gap-2 rounded-full p-1 bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600">
                                <button onClick={theme === 'dark' ? toggleTheme : undefined} className={`px-3 py-1 text-sm rounded-full transition-colors ${theme === 'light' ? 'bg-white shadow' : 'text-slate-400'}`}>Light</button>
                                <button onClick={theme === 'light' ? toggleTheme : undefined} className={`px-3 py-1 text-sm rounded-full transition-colors ${theme === 'dark' ? 'bg-slate-900 shadow' : 'text-slate-400'}`}>Dark</button>
                            </div>
                        </div>
                         <div className="border-t border-slate-200 dark:border-slate-700 pt-6">
                            <div className="flex items-center justify-between">
                                <span className="font-semibold">Color</span>
                                <div className="flex items-center gap-3">
                                    {THEME_COLORS.map(color => (
                                        <button key={color.name} onClick={() => setThemeColor(color.name as ThemeColor)} className={`w-8 h-8 rounded-full ${color.color} transition-transform hover:scale-110 ${themeColor === color.name ? 'ring-2 ring-offset-2 ring-offset-white dark:ring-offset-slate-800 ring-current' : ''}`}></button>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                
                {/* Notifications Section */}
                <section>
                    <h2 className="text-sm font-bold uppercase text-slate-500 dark:text-slate-400 mb-3 px-2">Notifications</h2>
                     <div className={`${sectionCardStyle} divide-y divide-slate-200 dark:divide-slate-700`}>
                        <div className="p-6 space-y-3">
                            <p className="font-semibold">Permission Status</p>
                            <div className={`px-4 py-2 rounded-lg text-sm text-center font-medium ${
                                notificationPermission === 'granted' ? 'bg-green-100 dark:bg-green-900/50 text-green-700 dark:text-green-300' :
                                notificationPermission === 'denied' ? 'bg-red-100 dark:bg-red-900/50 text-red-700 dark:text-red-300' :
                                'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                            }`}>
                                Status: {notificationPermission.charAt(0).toUpperCase() + notificationPermission.slice(1)}
                            </div>
                            {notificationPermission === 'default' && (
                                <button onClick={requestNotificationPermission} className="w-full mt-4 bg-slate-200 dark:bg-slate-600 hover:bg-slate-300 dark:hover:bg-slate-500 font-semibold py-2 rounded-lg transition-colors">
                                Enable Notifications
                                </button>
                            )}
                            {notificationPermission === 'denied' && (
                                <p className="text-xs text-red-500 mt-3 text-center">Notifications are blocked. You'll need to enable them in your browser's site settings to receive reminders.</p>
                            )}
                        </div>
                        <div className="p-6">
                            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                                <div className="flex items-center gap-4">
                                    <BellIcon className="w-6 h-6 text-green-500" />
                                    <div className="flex-grow">
                                        <p className="font-semibold">Daily Reminder</p>
                                        <p className="text-xs text-slate-500">Get a daily nudge to keep learning.</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 w-full sm:w-auto">
                                    <input type="time" value={reminderTime} onChange={e => setReminderTime(e.target.value)} className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 w-full" />
                                    <button onClick={handleSetReminder} disabled={isSaved} className={`px-3 py-1.5 rounded-lg font-semibold text-sm transition-colors text-white ${isSaved ? 'bg-green-600' : 'bg-primary-600 hover:bg-primary-700'}`}>
                                        {isSaved ? <CheckBadgeIcon className="w-5 h-5"/> : 'Save'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Data Management Section */}
                <section>
                     <h2 className="text-sm font-bold uppercase text-slate-500 dark:text-slate-400 mb-3 px-2">Account</h2>
                     <div className={`${sectionCardStyle} overflow-hidden`}>
                        <button onClick={handleReset} className="w-full flex items-center justify-between p-5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
                            <div className="flex items-center gap-4">
                                <TrashIcon className="w-6 h-6" />
                                <span className="font-semibold">Reset Progress</span>
                            </div>
                        </button>
                         <div className="border-t border-slate-200 dark:border-slate-700">
                            <button onClick={handleLogout} className="w-full flex items-center justify-between p-5 hover:bg-slate-100 dark:hover:bg-slate-700/50 transition-colors">
                                <div className="flex items-center gap-4">
                                    <ArrowRightOnRectangleIcon className="w-6 h-6" />
                                    <span className="font-semibold">Log Out</span>
                                </div>
                            </button>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default Settings;