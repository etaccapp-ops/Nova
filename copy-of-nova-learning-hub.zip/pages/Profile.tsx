import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { AcademicCapIcon, ChartBarIcon, TrophyIcon, CheckBadgeIcon, PencilIcon, StarIcon, CalendarDaysIcon, DropIcon, Cog6ToothIcon } from '../components/Icons';

const LearningActivityGraph = () => {
    const days = Array.from({ length: 182 }, (_, i) => { // Approx 26 weeks for a 26x7 grid
        const activity = Math.random();
        let color = 'bg-slate-200 dark:bg-slate-700/50';
        if (activity > 0.8) color = 'bg-green-400';
        else if (activity > 0.6) color = 'bg-green-500';
        else if (activity > 0.4) color = 'bg-green-600';
        else if (activity > 0.2) color = 'bg-green-700';
        const activityLevel = Math.floor(activity * 10);
        return <div key={i} className={`aspect-square w-full rounded-sm ${color}`} title={`Activity: ${activityLevel}/10`}></div>;
    });

    return <div className="grid grid-cols-[repeat(26,minmax(0,1fr))] gap-1.5">{days}</div>;
};

const StatItem: React.FC<{ icon: React.ReactNode; label: string; value: string | number; }> = ({ icon, label, value }) => (
    <div className="flex items-center justify-between py-3 border-b border-slate-200 dark:border-slate-700/50 last:border-b-0">
        <div className="flex items-center gap-4">
            <div className="flex-shrink-0 w-7 h-7">{icon}</div>
            <p className="text-slate-600 dark:text-slate-300">{label}</p>
        </div>
        <p className="font-bold text-lg text-slate-800 dark:text-slate-100">{value}</p>
    </div>
);

const Profile: React.FC = () => {
  const { user } = useUser();
  const navigate = useNavigate();
  const cardBaseStyle = "bg-white dark:bg-slate-800/50 dark:backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700";

  return (
    <div className="bg-slate-50 dark:bg-gradient-to-b from-slate-950 to-slate-900 min-h-screen text-slate-800 dark:text-slate-200">
        <div className="p-4 md:p-6 space-y-8">
            <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                {/* --- Left Column: Profile Info --- */}
                <div className="flex flex-col items-center lg:items-start text-center lg:text-left">
                    <img src={user.avatar} alt="User avatar" className="w-28 h-28 rounded-full border-4 border-yellow-300 dark:border-yellow-400 shadow-lg" />
                    <h1 className="text-3xl font-bold mt-4 text-slate-900 dark:text-white">{user.name}</h1>
                    <p className="text-primary-500 dark:text-primary-400 font-semibold">{user.title}</p>
                    <span className="inline-flex items-center gap-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold mt-3 px-2.5 py-1 rounded-full border border-slate-300 dark:border-slate-600">
                        <TrophyIcon className="w-4 h-4 text-yellow-500" />
                        {user.status}
                    </span>
                    <div className="mt-6 flex w-full max-w-xs lg:max-w-none gap-4">
                        <Link to="/profile/edit" className="flex-1 bg-slate-200 dark:bg-slate-700/50 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 hover:bg-slate-300 dark:hover:bg-slate-700 transition border border-slate-300 dark:border-slate-600">
                            <PencilIcon className="w-5 h-5" /> Edit Profile
                        </Link>
                        <Link to="/settings" className="flex-1 bg-slate-200 dark:bg-slate-700/50 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 hover:bg-slate-300 dark:hover:bg-slate-700 transition border border-slate-300 dark:border-slate-600">
                            <Cog6ToothIcon className="w-5 h-5" /> App Settings
                        </Link>
                    </div>
                </div>

                {/* --- Right Column: Stats Card --- */}
                <div className="bg-white/70 dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 p-4 space-y-4">
                    <div className="flex justify-around text-center">
                        <div className="p-2">
                            <CalendarDaysIcon className="w-6 h-6 mx-auto text-slate-500 dark:text-slate-400" />
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Daily Streak</p>
                            <p className="text-lg font-bold text-yellow-500">{user.dailyStreak} Days</p>
                        </div>
                        <div className="p-2">
                            <CalendarDaysIcon className="w-6 h-6 mx-auto text-slate-500 dark:text-slate-400" />
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Longest Streak</p>
                            <p className="text-lg font-bold text-orange-500">{user.longestStreak} Days</p>
                        </div>
                    </div>
                    <div className="border-t border-slate-200 dark:border-slate-700/50 pt-4 flex flex-col items-center">
                        <p className="font-semibold">Your Points</p>
                        <p className="text-xs text-slate-500">+20 since last week</p>
                        <div className="relative h-28 w-28 my-2">
                            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                                <circle className="text-slate-200 dark:text-slate-700" stroke="currentColor" strokeWidth="3" fill="none" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                                <circle className="text-primary-500" stroke="currentColor" strokeWidth="3" strokeLinecap="round" fill="none" strokeDasharray={`${user.points}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                            </svg>
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-4xl font-bold">{user.points}</div>
                        </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="bg-slate-100 dark:bg-slate-900/40 rounded-lg p-2">
                            <TrophyIcon className="w-5 h-5 mx-auto text-primary-500" />
                            <p className="font-semibold mt-1">{user.points}</p>
                            <p className="text-slate-500">Total Points</p>
                        </div>
                         <div className="bg-slate-100 dark:bg-slate-900/40 rounded-lg p-2">
                            <DropIcon className="w-5 h-5 mx-auto text-blue-500" />
                            <p className="font-semibold mt-1">{user.longestStreak}</p>
                            <p className="text-slate-500">Longest</p>
                        </div>
                         <div className="bg-slate-100 dark:bg-slate-900/40 rounded-lg p-2">
                            <CheckBadgeIcon className="w-5 h-5 mx-auto text-green-500" />
                            <p className="font-semibold mt-1">{user.challengesCompleted}</p>
                            <p className="text-slate-500">Completed</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className={`relative ${cardBaseStyle} p-6`}>
                <div className="absolute top-4 right-4 text-primary-400 opacity-10 dark:opacity-30">
                    <StarIcon className="w-16 h-16" />
                </div>
                <h3 className="font-bold text-lg">Certificate of Mastery</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-[80%] mt-1">Complete all courses to unlock your final certificate and validate your skills.</p>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 mt-4">
                    <div className="bg-primary-600 h-2.5 rounded-full" style={{width: `${user.certificateProgress}%`}}></div>
                </div>
                 <p className="text-right text-sm font-semibold mt-1">{user.certificateProgress}%</p>
            </section>
            
            <section className={`${cardBaseStyle} p-4 sm:p-6`}>
                <h3 className="font-bold text-lg mb-2">Stats</h3>
                <div>
                    <StatItem icon={<ChartBarIcon className="text-primary-500 dark:text-primary-400" />} label="Total Points" value={user.points} />
                    <StatItem icon={<TrophyIcon className="text-yellow-500 dark:text-yellow-400" />} label="Longest Streak" value={`${user.longestStreak} days`} />
                    <StatItem icon={<CheckBadgeIcon className="text-green-500 dark:text-green-400" />} label="Challenges Completed" value={user.challengesCompleted} />
                    <StatItem icon={<AcademicCapIcon className="text-purple-500 dark:text-purple-400" />} label="Achievements" value={user.achievements} />
                </div>
            </section>
            
            <section className={`${cardBaseStyle} p-6`}>
                <h3 className="font-bold text-lg mb-4">Learning Activity</h3>
                <LearningActivityGraph />
                 <p className="text-xs text-slate-500 mt-3 text-center">Mock data representing last six months' activity.</p>
            </section>

             <section className={`${cardBaseStyle} p-6 text-center`}>
                <h3 className="font-bold text-lg">My Learning</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">No courses started yet. Explore courses to begin!</p>
            </section>
        </div>
    </div>
  );
};

export default Profile;