import React from 'react';
import { CheckBadgeIcon } from './Icons';

export interface ToastMessage {
    id: number;
    message: string;
}

interface ToastContainerProps {
    toasts: ToastMessage[];
}

export const ToastContainer: React.FC<ToastContainerProps> = ({ toasts }) => {
  return (
    <div className="fixed bottom-24 right-0 left-0 md:left-auto md:right-4 z-[100] flex flex-col items-center md:items-end space-y-3 px-4">
      {toasts.map(toast => (
        <div 
          key={toast.id} 
          className="animate-fade-in-up flex items-center gap-3 bg-slate-800 text-white px-5 py-3 rounded-full shadow-2xl border border-slate-700"
          role="status"
          aria-live="polite"
        >
          <CheckBadgeIcon className="w-6 h-6 text-green-400" />
          <p className="font-semibold text-sm">{toast.message}</p>
        </div>
      ))}
    </div>
  );
};
