import React from 'react';
import { NavLink } from 'react-router-dom';
import { HomeIcon, BookOpenIcon, BeakerIcon, UserCircleIcon, BookmarkIcon } from './Icons';
import { useBookmarks } from '../contexts/BookmarkContext';

interface NavItem {
  path: string;
  label: string;
  icon: (props: { isActive: boolean }) => React.ReactNode;
}

const navItems: NavItem[] = [
  { path: '/dashboard', label: 'Home', icon: () => <HomeIcon /> },
  { path: '/courses', label: 'Courses', icon: () => <BookOpenIcon /> },
  { path: '/challenges', label: 'Labs', icon: () => <BeakerIcon /> },
  { path: '/bookmarks', label: 'Bookmarks', icon: ({ isActive }) => <BookmarkIcon solid={isActive} /> },
  { path: '/profile', label: 'Profile', icon: () => <UserCircleIcon /> },
];

const FooterNav: React.FC = () => {
  const { bookmarks } = useBookmarks();
  const bookmarkCount = bookmarks.length;
  const activeLinkClass = "text-primary-600 dark:text-primary-400 scale-110";
  const inactiveLinkClass = "text-slate-500 dark:text-slate-400";

  return (
    <footer className="fixed bottom-0 left-0 right-0 h-20 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border-t border-slate-200/80 dark:border-slate-700/60 shadow-[0_-5px_20px_-5px_rgba(0,0,0,0.1)] dark:shadow-[0_-5px_20px_-5px_rgba(0,0,0,0.25)] z-50">
      <nav className="h-full">
        <ul className="flex justify-around items-center h-full max-w-lg mx-auto px-4">
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) => 
                  `flex flex-col items-center justify-center gap-1 transition-all duration-200 ease-in-out transform hover:text-primary-500 dark:hover:text-primary-400 ${isActive ? activeLinkClass : inactiveLinkClass}`
                }
              >
                {({ isActive }) => (
                  <>
                    <div className="relative w-7 h-7">
                      {item.icon({ isActive })}
                      {item.label === 'Bookmarks' && bookmarkCount > 0 && (
                        <span className="absolute -top-1.5 -right-2.5 bg-red-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white dark:border-slate-900/80">
                          {bookmarkCount > 9 ? '9+' : bookmarkCount}
                        </span>
                      )}
                    </div>
                    <span className="text-xs font-medium">{item.label}</span>
                  </>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </footer>
  );
};

export default FooterNav;
