import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { LabChallenge } from '../types';
import { analyzeCode } from '../services/geminiService';
import { SparklesIcon, EyeIcon, CodeBracketIcon, ExpandIcon, ContractIcon, ExclamationTriangleIcon } from './Icons';

interface AnalysisResult {
    correctnessPercentage: number;
    suggestions: string[];
}

interface CodeEditorProps {
  challenge: LabChallenge;
}

const SELF_CLOSING_TAGS = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);

const highlightHtml = (code: string, errorLines: Set<number>) => {
    const lines = code.split('\n');
    return lines.map((line, index) => {
        const isErrorLine = errorLines.has(index + 1);
        const highlightedLine = line
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/(&lt;!--[\s\S]*?--&gt;)/g, '<span class="token-comment">$1</span>') // Comments
            .replace(/(&lt;\/?)(\w+)/g, '$1<span class="token-tag">$2</span>') // Tag names
            .replace(/(\s+)([\w.:-]+)=(".*?"|'.*?'|[^\s>]+)/g, '$1<span class="token-attr-name">$2</span>=<span class="token-attr-value">$3</span>') // Attributes with values (now supports unquoted)
            .replace(/(&gt;)/g, '<span class="token-tag">$1</span>'); // Closing bracket
        return `<span class="line-bg ${isErrorLine ? 'line-bg-error' : ''}">${highlightedLine || ' '}</span>`;
    }).join('');
};

const highlightCss = (code: string) => {
    let highlightedCode = code
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

    // Comments
    highlightedCode = highlightedCode.replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="token-comment">$1</span>');
    // Rules
    highlightedCode = highlightedCode.replace(/({[^}]+})/g, (block) => {
        return block.replace(
            /([\w-]+)\s*:\s*([^;]+)/g,
            (decl, prop, val) => `<span class="token-property">${prop}</span>: <span class="token-value">${val.trim()}</span>`
        );
    });
    // Selectors
    highlightedCode = highlightedCode.replace(/(^|})\s*([^{]+?)\s*(?={)/g, '$1<span class="token-selector">$2</span>');
    
    return highlightedCode.split('\n').map(line => `<span class="line-bg">${line || ' '}</span>`).join('');
}


const validateHtml = (code: string): string[] => {
    const stack: { tagName: string, line: number }[] = [];
    const errors: string[] = [];
    const lines = code.split('\n');
    const tagRegex = /<(\/?)(\w+)([^>]*)>/g;
    
    lines.forEach((line, lineIndex) => {
        let match;
        while ((match = tagRegex.exec(line)) !== null) {
            const [, isClosing, tagNameStr] = match;
            const tagName = tagNameStr.toLowerCase();
            const isSelfClosing = SELF_CLOSING_TAGS.has(tagName) || match[3].trim().endsWith('/');
            if (isSelfClosing) continue;

            if (isClosing) {
                if (stack.length === 0) {
                    errors.push(`Error on line ${lineIndex + 1}: Unexpected closing tag <code>&lt;/${tagName}&gt;</code>.`);
                } else if (stack[stack.length - 1].tagName === tagName) {
                    stack.pop();
                } else {
                    const lastTag = stack[stack.length - 1];
                    errors.push(`Error on line ${lineIndex + 1}: Mismatched closing tag. Expected <code>&lt;/${lastTag.tagName}&gt;</code> (from line ${lastTag.line}) but got <code>&lt;/${tagName}&gt;</code>.`);
                }
            } else {
                stack.push({ tagName, line: lineIndex + 1 });
            }
        }
    });

    // Report all unclosed tags
    stack.forEach(unclosedTag => {
        errors.push(`Error on line ${unclosedTag.line}: Unclosed tag <code>&lt;${unclosedTag.tagName}&gt;</code> was never closed.`);
    });

    return errors;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ challenge }) => {
  const getLocalStorageKey = (challengeId: string) => `challenge-code-${challengeId}`;

  const [htmlCode, setHtmlCode] = useState(() => {
    const saved = localStorage.getItem(getLocalStorageKey(challenge.id));
    return saved ? JSON.parse(saved).html : challenge.initialCode.html;
  });
  const [cssCode, setCssCode] = useState(() => {
    const saved = localStorage.getItem(getLocalStorageKey(challenge.id));
    return saved ? JSON.parse(saved).css : (challenge.initialCode.css || '');
  });

  const [activeEditorTab, setActiveEditorTab] = useState<'html' | 'css'>('html');
  const [activeRightTab, setActiveRightTab] = useState<'preview' | 'analysis'>('preview');
  
  const [isLoading, setIsLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  
  const [errors, setErrors] = useState<string[]>([]);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const debounceTimeoutRef = useRef<number | null>(null);
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  
  const isHtml = activeEditorTab === 'html';
  const code = isHtml ? htmlCode : cssCode;
  const setCode = isHtml ? setHtmlCode : setCssCode;
  
  const htmlErrorLines = useMemo(() => new Set(errors.map(err => parseInt(err.match(/line (\d+)/)?.[1] || '0', 10))), [errors]);
  const highlightedHtmlCode = useMemo(() => highlightHtml(htmlCode, htmlErrorLines), [htmlCode, htmlErrorLines]);
  const highlightedCssCode = useMemo(() => highlightCss(cssCode), [cssCode]);
  
  const highlightedCode = isHtml ? highlightedHtmlCode : highlightedCssCode;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullScreen) {
        setIsFullScreen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullScreen]);
  
  useEffect(() => {
    const saved = localStorage.getItem(getLocalStorageKey(challenge.id));
    if (saved) {
      const { html, css } = JSON.parse(saved);
      setHtmlCode(html);
      setCssCode(css);
    } else {
      setHtmlCode(challenge.initialCode.html);
      setCssCode(challenge.initialCode.css || '');
    }
    setAnalysisResult(null);
    setActiveRightTab('preview');
  }, [challenge]);

  useEffect(() => {
    if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
    }
    debounceTimeoutRef.current = window.setTimeout(() => {
        const dataToSave = JSON.stringify({ html: htmlCode, css: cssCode });
        localStorage.setItem(getLocalStorageKey(challenge.id), dataToSave);
    }, 500);

    return () => {
        if(debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
    }
  }, [htmlCode, cssCode, challenge.id]);

  useEffect(() => {
    const handler = setTimeout(() => {
        if (isHtml && challenge.editorConfig?.syntaxErrorDetection) {
            setErrors(validateHtml(htmlCode));
        } else {
            setErrors([]);
        }
    }, 200);
    return () => clearTimeout(handler);
  }, [htmlCode, isHtml, challenge.editorConfig?.syntaxErrorDetection]);

  const handleAnalyze = useCallback(async () => {
    setActiveRightTab('analysis');
    setIsLoading(true);
    setAnalysisResult(null);
    try {
        const result = await analyzeCode(htmlCode, challenge);
        setAnalysisResult(result);
    } catch (error) {
        console.error("Analysis failed:", error);
        setAnalysisResult({ correctnessPercentage: 0, suggestions: ["An error occurred during analysis. Please try again."] });
    } finally {
        setIsLoading(false);
    }
  }, [htmlCode, challenge]);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const { value } = e.target;
    setCode(value);
  };

  const syncScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    const target = e.currentTarget;
    if (preRef.current) {
        preRef.current.scrollTop = target.scrollTop;
        preRef.current.scrollLeft = target.scrollLeft;
    }
  };

  const srcDoc = `<html><head><style>${cssCode}</style></head><body>${htmlCode}</body></html>`;

  const editorTabStyle = "px-4 py-2 font-mono text-sm cursor-pointer transition-colors flex items-center gap-2";
  const editorActiveTabStyle = "bg-[#1e1e1e] text-white";
  const editorInactiveTabStyle = "bg-slate-700 text-slate-400 hover:bg-slate-600";
  
  const rightTabStyle = "px-4 py-2 text-sm font-semibold cursor-pointer transition-colors border-b-2 flex items-center gap-2";
  const rightActiveTabStyle = "border-blue-500 text-slate-800 dark:text-white";
  const rightInactiveTabStyle = "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-white";

  return (
    <div className={
        isFullScreen 
        ? "fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm p-2 sm:p-4 grid grid-cols-1 lg:grid-cols-2 gap-4 font-mono text-sm"
        : "grid grid-cols-1 lg:grid-cols-2 gap-4 h-full min-h-[500px] font-mono text-sm"
    }>
      <div className="flex flex-col bg-slate-800 rounded-lg overflow-hidden border border-slate-700">
        <div className="flex bg-slate-900 flex-shrink-0 justify-between items-center">
            <div className="flex">
                <button onClick={() => setActiveEditorTab('html')} className={`${editorTabStyle} ${activeEditorTab === 'html' ? editorActiveTabStyle : editorInactiveTabStyle}`}>
                    <CodeBracketIcon className="w-4 h-4" /> index.html
                </button>
                {challenge.initialCode.css && (
                    <button onClick={() => setActiveEditorTab('css')} className={`${editorTabStyle} ${activeEditorTab === 'css' ? editorActiveTabStyle : editorInactiveTabStyle}`}>
                        <CodeBracketIcon className="w-4 h-4" /> style.css
                    </button>
                )}
            </div>
            <button 
                onClick={() => setIsFullScreen(fs => !fs)} 
                title={isFullScreen ? "Restore" : "Fullscreen"} 
                className="p-2 text-slate-400 hover:bg-slate-700 rounded-md m-1 transition-colors"
            >
                {isFullScreen ? <ContractIcon className="w-5 h-5" /> : <ExpandIcon className="w-5 h-5" />}
            </button>
        </div>
        <div className="relative flex-grow min-h-0">
          <div className="code-editor-container">
              <div className="editor-content">
                  <textarea ref={editorRef} value={code} onChange={handleChange} onScroll={syncScroll} className="editor-textarea" spellCheck="false" />
                  <pre ref={preRef} className="editor-highlight-pre" aria-hidden="true">
                      <code dangerouslySetInnerHTML={{ __html: highlightedCode }} />
                  </pre>
              </div>
          </div>
        </div>
        {isHtml && errors.length > 0 && challenge.editorConfig?.syntaxErrorDetection && (
            <div className="bg-red-900/50 p-3 border-t border-red-500/30 max-h-28 overflow-y-auto flex-shrink-0 flex gap-3 error-panel">
                <ExclamationTriangleIcon className="w-5 h-5 text-red-300 flex-shrink-0 mt-0.5" />
                <div>
                    <h4 className="font-bold text-red-300">HTML Syntax Error</h4>
                    <ul className="text-xs text-red-300 space-y-1 mt-1">
                        {errors.map((err, i) => (
                            <li key={i} dangerouslySetInnerHTML={{ __html: err }} />
                        ))}
                    </ul>
                </div>
            </div>
        )}
      </div>
      <div className="flex flex-col bg-white dark:bg-slate-800 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
        <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 px-4 flex-shrink-0">
            <div className="flex">
                <button onClick={() => setActiveRightTab('preview')} className={`${rightTabStyle} ${activeRightTab === 'preview' ? rightActiveTabStyle : rightInactiveTabStyle}`}><EyeIcon className="w-4 h-4" /> Preview</button>
                <button onClick={() => setActiveRightTab('analysis')} className={`${rightTabStyle} ${activeRightTab === 'analysis' ? rightActiveTabStyle : rightInactiveTabStyle}`}><SparklesIcon className="w-4 h-4" /> Analysis</button>
            </div>
            <button onClick={handleAnalyze} disabled={isLoading} className="flex items-center gap-2 bg-violet-600 text-white text-xs font-bold py-2 px-3 rounded-lg hover:bg-violet-700 disabled:bg-violet-400/50 transition shadow-sm">
                <SparklesIcon className="w-4 h-4" />
                {isLoading ? 'Analyzing...' : 'Analyze'}
            </button>
        </div>
        <div className="flex-grow relative overflow-y-auto">
            {activeRightTab === 'preview' ? (
                <iframe srcDoc={srcDoc} title="Preview" sandbox="allow-scripts" className="w-full h-full" />
            ) : (
                <div className="p-6 font-sans text-base">
                    {analysisResult ? (
                        <div className="space-y-4 animate-fade-in text-slate-800 dark:text-slate-200">
                            <div className="text-center p-4 bg-slate-100 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700">
                                <p className="text-lg font-semibold">Correctness Score</p>
                                <p className="text-5xl font-bold text-violet-500 dark:text-violet-400">{analysisResult.correctnessPercentage}%</p>
                            </div>
                            <div>
                                <h4 className="font-semibold text-lg">Suggestions:</h4>
                                <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 space-y-2 text-sm mt-2">
                                    {analysisResult.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                                </ul>
                            </div>
                        </div>
                    ) : (
                         <div className="text-center p-8 bg-slate-100 dark:bg-slate-900/50 rounded-lg border border-dashed border-slate-300 dark:border-slate-700 h-full flex flex-col justify-center items-center">
                            <div className="w-12 h-12 text-slate-400 mb-4"><SparklesIcon /></div>
                            <h3 className="font-semibold text-slate-700 dark:text-slate-300">Get AI-Powered Feedback</h3>
                            <p className="text-slate-500 text-sm mt-1">Click the "Analyze" button to check your code against the challenge requirements.</p>
                        </div>
                    )}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};